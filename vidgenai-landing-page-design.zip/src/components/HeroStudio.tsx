import React, { useState, useRef, useEffect } from "react";
import {
  Play,
  Pause,
  Sparkles,
  Sliders,
  Video,
  Camera,
  Gauge,
  RefreshCw,
  Maximize2,
  CheckCircle2,
  Wand2,
  Layers,
} from "lucide-react";
import { HERO_PRESETS, StudioPreset } from "../data/studioData";

interface HeroStudioProps {
  externalPreset: StudioPreset | null;
  promptInputRef: React.RefObject<HTMLInputElement | null>;
  onOpenShowreel: () => void;
  onStartFree: () => void;
}

export const HeroStudio: React.FC<HeroStudioProps> = ({
  externalPreset,
  promptInputRef,
  onOpenShowreel,
  onStartFree,
}) => {
  const [activePreset, setActivePreset] = useState<StudioPreset>(HERO_PRESETS[0]);
  const [promptText, setPromptText] = useState<string>(HERO_PRESETS[0].prompt);
  const [motionStrength, setMotionStrength] = useState<number>(HERO_PRESETS[0].motionStrength);
  const [fps, setFps] = useState<number>(HERO_PRESETS[0].fps);
  const [cameraControl, setCameraControl] = useState<number>(HERO_PRESETS[0].cameraControl);
  const [seed, setSeed] = useState<number>(HERO_PRESETS[0].seed);

  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isRendering, setIsRendering] = useState<boolean>(false);
  const [renderStep, setRenderStep] = useState<number>(0);
  const [showHudGrid, setShowHudGrid] = useState<boolean>(true);
  const [renderSuccessToast, setRenderSuccessToast] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Sync external preset loaded from Showcase section
  useEffect(() => {
    if (externalPreset) {
      triggerDiffusionTransition(externalPreset);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [externalPreset]);

  // Adjust subtle playback speed based on Motion Strength slider
  useEffect(() => {
    if (videoRef.current) {
      const rate = Math.max(0.65, Math.min(1.45, 0.65 + (motionStrength / 10) * 0.7));
      videoRef.current.playbackRate = rate;
    }
  }, [motionStrength, activePreset]);

  const triggerDiffusionTransition = (nextPreset?: StudioPreset) => {
    if (isRendering) return;
    setIsRendering(true);
    setRenderStep(1);

    const stepTimer1 = setTimeout(() => setRenderStep(2), 200);
    const stepTimer2 = setTimeout(() => setRenderStep(3), 420);
    const stepTimer3 = setTimeout(() => setRenderStep(4), 620);

    setTimeout(() => {
      clearTimeout(stepTimer1);
      clearTimeout(stepTimer2);
      clearTimeout(stepTimer3);

      if (nextPreset) {
        setActivePreset(nextPreset);
        setPromptText(nextPreset.prompt);
        setMotionStrength(nextPreset.motionStrength);
        setFps(nextPreset.fps);
        setCameraControl(nextPreset.cameraControl);
        setSeed(nextPreset.seed);
      } else {
        // Cycle clip if user wrote a custom prompt or re-rolled seed
        const matchedByKeyword = HERO_PRESETS.find(
          (p) =>
            p.id !== activePreset.id &&
            ((promptText.toLowerCase().includes("astronaut") && p.id === "orbital-astronaut") ||
              (promptText.toLowerCase().includes("particle") && p.id === "quantum-vortex") ||
              (promptText.toLowerCase().includes("car") && p.id === "hover-car-neon"))
        );
        if (matchedByKeyword) {
          setActivePreset(matchedByKeyword);
        }
        setSeed(Math.floor(10000000 + Math.random() * 89999999));
      }

      setIsRendering(false);
      setRenderStep(0);
      setIsPlaying(true);
      setRenderSuccessToast(true);
      setTimeout(() => setRenderSuccessToast(false), 2600);
    }, 800);
  };

  const togglePlayback = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const getCameraDescriptor = (val: number) => {
    if (Math.abs(val) < 0.4) return "Locked Tripod 0.0°";
    if (val > 0) return `Pan Right +${val.toFixed(1)}°`;
    return `Pan Left ${val.toFixed(1)}°`;
  };

  // Subtle interactive pan transform inside 16:9 viewport
  const panOffsetPercent = -(cameraControl * 0.85);

  return (
    <section className="relative overflow-hidden pt-12 pb-20 sm:pt-16 sm:pb-28">
      {/* Architectural Grid & Controlled Radial Studio Glows */}
      <div className="pointer-events-none absolute inset-0 bg-studio-grid mask-radial-fade" />
      <div
        className="pointer-events-none absolute -top-28 left-1/2 -translate-x-1/2 h-[520px] w-[960px] rounded-full opacity-30 blur-[130px]"
        style={{
          background:
            "radial-gradient(circle, rgba(0,229,255,0.42) 0%, rgba(124,58,237,0.38) 52%, transparent 75%)",
        }}
      />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Centered Editorial Copy Stack */}
        <div className="mx-auto max-w-4xl text-center">
          {/* Pill Badge */}
          <div className="inline-flex items-center gap-2.5 rounded-full border border-[#00E5FF]/30 bg-[#0B1222]/85 px-4 py-1.5 text-xs sm:text-sm font-medium text-[#E2E8F0] shadow-[0_0_24px_-4px_rgba(0,229,255,0.3)] backdrop-blur-md mb-7">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00E5FF] opacity-80" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#00E5FF]" />
            </span>
            <span>✨ Powered by VidGen v3.0 — Real-Time Motion Diffusion</span>
          </div>

          {/* H1 Headline */}
          <h1 className="font-heading text-4xl sm:text-5xl md:text-6xl lg:text-[66px] font-bold tracking-[-0.03em] leading-[1.06] text-[#F8FAFC]">
            Turn Text &amp; Images into{" "}
            <span className="bg-gradient-to-r from-[#00E5FF] via-[#60A5FA] to-[#A855F7] bg-clip-text text-transparent">
              Cinematic AI Video
            </span>{" "}
            in Seconds
          </h1>

          {/* Subheadline */}
          <p className="mx-auto mt-6 max-w-2xl text-base sm:text-lg md:text-[19px] leading-relaxed text-[#94A3B8]">
            The fastest AI motion model for creators, studios, and marketing teams. Generate 4K
            camera movements, realistic lighting, and fluid character animation with zero rendering
            delay.
          </p>

          {/* CTA Row */}
          <div className="mt-9 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              type="button"
              onClick={onStartFree}
              className="btn-glow-gradient w-full sm:w-auto inline-flex items-center justify-center gap-2.5 rounded-xl px-7 py-4 text-base font-semibold text-white cursor-pointer"
            >
              <Sparkles className="h-4 w-4" />
              <span>Start Generating Free</span>
            </button>

            <button
              type="button"
              onClick={onOpenShowreel}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 rounded-xl border border-white/15 bg-white/[0.04] hover:bg-white/[0.08] hover:border-[#00E5FF]/40 backdrop-blur-xl px-7 py-4 text-base font-semibold text-[#F8FAFC] transition-all cursor-pointer"
            >
              <span>Watch 4K Showreel</span>
              <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-[#00E5FF]/15 text-[#00E5FF] text-xs">
                ▶
              </span>
            </button>
          </div>

          {/* Micro-Copy */}
          <p className="mt-4 text-xs sm:text-sm font-medium text-[#64748B]">
            No credit card required <span className="mx-1.5 text-white/25">•</span> 50 free render
            credits <span className="mx-1.5 text-white/25">•</span> Commercial usage allowed
          </p>
        </div>

        {/* HERO MEDIA FRAME: Interactive 16:9 Video Studio Preview UI */}
        <div
          id="hero-studio"
          className="relative mx-auto mt-12 sm:mt-14 max-w-6xl rounded-2xl sm:rounded-3xl p-[1px] bg-gradient-to-b from-[#00E5FF]/40 via-white/10 to-[#7C3AED]/40 shadow-[0_30px_100px_-20px_rgba(0,229,255,0.22),0_0_80px_-25px_rgba(124,58,237,0.3)]"
        >
          <div className="rounded-2xl sm:rounded-[23px] bg-[#080C16]/95 backdrop-blur-2xl overflow-hidden">
            {/* Top Studio Window Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/[0.08] bg-[#0A0F1D] px-4 py-3 sm:px-6">
              <div className="flex items-center gap-3">
                {/* Window traffic lights */}
                <div className="hidden sm:flex items-center gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-full bg-white/15" />
                  <span className="h-2.5 w-2.5 rounded-full bg-white/15" />
                  <span className="h-2.5 w-2.5 rounded-full bg-[#00E5FF]/60" />
                </div>
                <div className="h-4 w-[1px] bg-white/10 hidden sm:block" />
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1.5 rounded-md bg-[#00E5FF]/10 border border-[#00E5FF]/30 px-2.5 py-1 font-mono text-[11px] font-medium text-[#00E5FF]">
                    <Video className="h-3 w-3" />
                    {activePreset.model}
                  </span>
                  <span className="hidden md:inline-flex items-center rounded-md bg-white/[0.04] border border-white/10 px-2.5 py-1 font-mono text-[11px] text-[#94A3B8] tabular-nums">
                    {activePreset.resolution}
                  </span>
                </div>
              </div>

              {/* Preset Scene Switcher Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto max-w-full py-0.5">
                {HERO_PRESETS.map((preset) => {
                  const active = preset.id === activePreset.id;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => triggerDiffusionTransition(preset)}
                      className={`whitespace-nowrap rounded-lg px-2.5 py-1 text-xs font-medium transition-all cursor-pointer ${
                        active
                          ? "bg-gradient-to-r from-[#00E5FF]/20 to-[#7C3AED]/25 text-white border border-[#00E5FF]/45 shadow-[0_0_15px_rgba(0,229,255,0.2)]"
                          : "text-[#94A3B8] hover:text-white bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.06]"
                      }`}
                    >
                      {preset.label}
                    </button>
                  );
                })}
              </div>

              {/* Telemetry Right Status */}
              <div className="hidden lg:flex items-center gap-3 font-mono text-[11px] text-[#94A3B8] tabular-nums">
                <span className="inline-flex items-center gap-1.5 text-[#10B981]">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#10B981] animate-pulse" />
                  H200 LIVE ({activePreset.renderTime})
                </span>
                <span className="text-white/20">|</span>
                <span>SEED #{seed}</span>
              </div>
            </div>

            {/* 16:9 High-Resolution Video Preview Viewport */}
            <div className="relative aspect-video w-full overflow-hidden bg-[#04060B] select-none">
              <video
                key={activePreset.videoUrl}
                ref={videoRef}
                src={activePreset.videoUrl}
                poster={activePreset.posterUrl}
                autoPlay
                muted
                loop
                playsInline
                style={{
                  transform: `scale(1.09) translateX(${panOffsetPercent}%)`,
                  transition: "transform 0.35s cubic-bezier(0.16, 1, 0.3, 1)",
                }}
                className={`h-full w-full object-cover transition-opacity duration-300 ${
                  isRendering ? "opacity-45 blur-[2px] scale-105" : "opacity-100"
                }`}
              />

              {/* Subtle Cinema Vignette */}
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#080C16] via-transparent to-[#05070C]/45 opacity-80" />

              {/* Optional Rule-of-Thirds Director Safe Frame Overlay */}
              {showHudGrid && (
                <div className="pointer-events-none absolute inset-6 sm:inset-10 border border-white/[0.12] rounded-lg">
                  {/* Corner reticles */}
                  <div className="absolute -top-[1px] -left-[1px] h-4 w-4 border-t-2 border-l-2 border-[#00E5FF]" />
                  <div className="absolute -top-[1px] -right-[1px] h-4 w-4 border-t-2 border-r-2 border-[#00E5FF]" />
                  <div className="absolute -bottom-[1px] -left-[1px] h-4 w-4 border-b-2 border-l-2 border-[#00E5FF]" />
                  <div className="absolute -bottom-[1px] -right-[1px] h-4 w-4 border-b-2 border-r-2 border-[#00E5FF]" />
                  {/* Center crosshair */}
                  <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center opacity-45">
                    <div className="h-5 w-[1px] bg-[#00E5FF]" />
                    <div className="h-[1px] w-5 bg-[#00E5FF] absolute" />
                  </div>
                </div>
              )}

              {/* Live Diffusion Scanline Overlay during Render */}
              {isRendering && (
                <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-[#05070C]/55 backdrop-blur-xs">
                  <div className="pointer-events-none absolute inset-x-0 h-28 bg-gradient-to-b from-transparent via-[#00E5FF]/25 to-transparent animate-scanline" />
                  <div className="rounded-2xl border border-[#00E5FF]/40 bg-[#090E1C]/90 px-6 py-4 text-center shadow-[0_0_40px_rgba(0,229,255,0.3)]">
                    <div className="flex items-center justify-center gap-2 font-mono text-xs font-semibold text-[#00E5FF]">
                      <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                      <span>REAL-TIME MOTION DIFFUSION PASS</span>
                    </div>
                    <div className="mt-2 font-mono text-xs text-[#CBD5E1] tabular-nums">
                      Denoising Latent Frame Block • Step {renderStep}/4 • {fps} FPS
                    </div>
                    <div className="mt-2.5 h-1.5 w-52 overflow-hidden rounded-full bg-white/10">
                      <div
                        className="h-full bg-gradient-to-r from-[#00E5FF] to-[#7C3AED] transition-all duration-200"
                        style={{ width: `${renderStep * 25}%` }}
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Top-Left Live Telemetry Pill */}
              <div className="absolute top-3 left-3 sm:top-5 sm:left-5 z-10 flex flex-wrap items-center gap-2">
                <div className="inline-flex items-center gap-2 rounded-lg bg-[#05070C]/75 border border-white/15 backdrop-blur-md px-3 py-1.5 font-mono text-[11px] text-[#F8FAFC] tabular-nums">
                  <span className="h-2 w-2 rounded-full bg-[#EF4444] animate-pulse" />
                  <span>REC • {fps} FPS</span>
                  <span className="text-white/25">|</span>
                  <span className="text-[#00E5FF]">MOTION {motionStrength.toFixed(1)}</span>
                </div>

                <div className="hidden sm:inline-flex items-center gap-1.5 rounded-lg bg-[#05070C]/75 border border-white/15 backdrop-blur-md px-3 py-1.5 font-mono text-[11px] text-[#CBD5E1] tabular-nums">
                  <Camera className="h-3 w-3 text-[#A855F7]" />
                  <span>{getCameraDescriptor(cameraControl)}</span>
                </div>

                {renderSuccessToast && (
                  <div className="inline-flex items-center gap-1.5 rounded-lg bg-[#10B981]/20 border border-[#10B981]/50 backdrop-blur-md px-3 py-1.5 font-mono text-[11px] text-[#34D399]">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    <span>4K Clip Synthesized in 0.78s</span>
                  </div>
                )}
              </div>

              {/* Bottom-Right Viewport Floating Controls */}
              <div className="absolute bottom-3 right-3 sm:bottom-5 sm:right-5 z-10 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowHudGrid(!showHudGrid)}
                  title="Toggle Director Guides"
                  className={`rounded-lg border px-2.5 py-1.5 font-mono text-[11px] backdrop-blur-md transition-colors cursor-pointer ${
                    showHudGrid
                      ? "border-[#00E5FF]/40 bg-[#00E5FF]/15 text-[#00E5FF]"
                      : "border-white/15 bg-[#05070C]/75 text-[#94A3B8] hover:text-white"
                  }`}
                >
                  GUIDES
                </button>
                <button
                  type="button"
                  onClick={togglePlayback}
                  aria-label={isPlaying ? "Pause preview" : "Play preview"}
                  className="inline-flex items-center justify-center rounded-lg border border-white/15 bg-[#05070C]/75 hover:bg-white/15 p-2 text-white backdrop-blur-md transition-colors cursor-pointer"
                >
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </button>
                <button
                  type="button"
                  onClick={onOpenShowreel}
                  aria-label="Open 4K Fullscreen Showreel"
                  className="inline-flex items-center justify-center rounded-lg border border-white/15 bg-[#05070C]/75 hover:bg-white/15 p-2 text-white backdrop-blur-md transition-colors cursor-pointer"
                >
                  <Maximize2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Bottom Interactive Studio Control Deck: Prompt Input + Motion Parameter Sliders */}
            <div className="border-t border-white/[0.09] bg-[#090D19] p-4 sm:p-6 space-y-5">
              {/* Simulated Prompt Input Bar */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  triggerDiffusionTransition();
                }}
                className="flex flex-col md:flex-row items-stretch md:items-center gap-3"
              >
                <div className="relative flex-1">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4">
                    <Wand2 className="h-4 w-4 text-[#00E5FF]" />
                  </div>
                  <input
                    ref={promptInputRef}
                    type="text"
                    value={promptText}
                    onChange={(e) => setPromptText(e.target.value)}
                    placeholder="Describe your scene, lighting, lens, and camera movement..."
                    aria-label="AI Video Prompt"
                    className="w-full rounded-xl border border-white/15 bg-[#05070C]/90 pl-11 pr-24 py-3.5 text-sm text-[#F8FAFC] placeholder-[#64748B] focus:border-[#00E5FF]/60 focus:outline-none focus:ring-2 focus:ring-[#00E5FF]/20 transition-all"
                  />
                  <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 hidden sm:inline-flex items-center rounded-md bg-white/[0.05] px-2 py-0.5 font-mono text-[10px] text-[#94A3B8]">
                    PROMPT v3
                  </span>
                </div>

                <button
                  type="submit"
                  disabled={isRendering}
                  className="btn-glow-gradient inline-flex items-center justify-center gap-2 rounded-xl px-6 py-3.5 text-sm font-semibold text-white disabled:opacity-60 cursor-pointer shrink-0"
                >
                  <RefreshCw className={`h-4 w-4 ${isRendering ? "animate-spin" : ""}`} />
                  <span>{isRendering ? "Rendering..." : "Render 4K Clip"}</span>
                </button>
              </form>

              {/* Motion Parameter Sliders Row */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
                {/* Slider 1: Motion Strength */}
                <div className="rounded-xl border border-white/[0.07] bg-[#05070C]/65 px-4 py-3">
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="inline-flex items-center gap-1.5 font-medium text-[#CBD5E1]">
                      <Sliders className="h-3.5 w-3.5 text-[#00E5FF]" />
                      Motion Strength
                    </span>
                    <span className="font-mono text-[#00E5FF] font-semibold tabular-nums">
                      {motionStrength.toFixed(1)} / 10
                    </span>
                  </div>
                  <input
                    type="range"
                    min={1}
                    max={10}
                    step={0.1}
                    value={motionStrength}
                    onChange={(e) => setMotionStrength(parseFloat(e.target.value))}
                    aria-label="Motion Strength"
                    className="studio-slider"
                  />
                  <div className="mt-1.5 flex justify-between font-mono text-[10px] text-[#64748B]">
                    <span>Subtle</span>
                    <span>Balanced</span>
                    <span>Hyper-Dynamic</span>
                  </div>
                </div>

                {/* Slider 2: FPS */}
                <div className="rounded-xl border border-white/[0.07] bg-[#05070C]/65 px-4 py-3">
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="inline-flex items-center gap-1.5 font-medium text-[#CBD5E1]">
                      <Gauge className="h-3.5 w-3.5 text-[#A855F7]" />
                      FPS (Frame Rate)
                    </span>
                    <span className="font-mono text-[#C084FC] font-semibold tabular-nums">
                      {fps} FPS
                    </span>
                  </div>
                  <input
                    type="range"
                    min={24}
                    max={60}
                    step={12}
                    value={fps}
                    onChange={(e) => setFps(parseInt(e.target.value, 10))}
                    aria-label="Frame Rate FPS"
                    className="studio-slider"
                  />
                  <div className="mt-1.5 flex justify-between font-mono text-[10px] text-[#64748B] tabular-nums">
                    <button
                      type="button"
                      onClick={() => setFps(24)}
                      className={`hover:text-white cursor-pointer ${fps === 24 ? "text-[#00E5FF]" : ""}`}
                    >
                      24 Film
                    </button>
                    <button
                      type="button"
                      onClick={() => setFps(36)}
                      className={`hover:text-white cursor-pointer ${fps === 36 ? "text-[#00E5FF]" : ""}`}
                    >
                      36 Smooth
                    </button>
                    <button
                      type="button"
                      onClick={() => setFps(48)}
                      className={`hover:text-white cursor-pointer ${fps === 48 ? "text-[#00E5FF]" : ""}`}
                    >
                      48 HFR
                    </button>
                    <button
                      type="button"
                      onClick={() => setFps(60)}
                      className={`hover:text-white cursor-pointer ${fps === 60 ? "text-[#00E5FF]" : ""}`}
                    >
                      60 Native
                    </button>
                  </div>
                </div>

                {/* Slider 3: Camera Control */}
                <div className="rounded-xl border border-white/[0.07] bg-[#05070C]/65 px-4 py-3">
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="inline-flex items-center gap-1.5 font-medium text-[#CBD5E1]">
                      <Layers className="h-3.5 w-3.5 text-[#00E5FF]" />
                      Camera Control
                    </span>
                    <span className="font-mono text-[#00E5FF] font-semibold tabular-nums">
                      {getCameraDescriptor(cameraControl)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={-5}
                    max={5}
                    step={0.5}
                    value={cameraControl}
                    onChange={(e) => setCameraControl(parseFloat(e.target.value))}
                    aria-label="Camera Control Pan Axis"
                    className="studio-slider"
                  />
                  <div className="mt-1.5 flex justify-between font-mono text-[10px] text-[#64748B]">
                    <span>← Pan Left</span>
                    <button
                      type="button"
                      onClick={() => setCameraControl(0)}
                      className="hover:text-white cursor-pointer"
                    >
                      Center 0°
                    </button>
                    <span>Pan Right →</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
