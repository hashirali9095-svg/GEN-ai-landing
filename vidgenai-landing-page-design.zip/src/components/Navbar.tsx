import React, { useState, useEffect } from "react";
import { Menu, X, ArrowUpRight } from "lucide-react";

interface NavbarProps {
  onOpenAuth: (mode: "signin" | "signup") => void;
  onFocusStudio: () => void;
  onOpenApiModal: () => void;
}

export const VidGenLogo: React.FC<{ className?: string }> = ({ className = "" }) => (
  <div className={`inline-flex items-center gap-2.5 select-none group ${className}`}>
    {/* Glowing SVG Icon Badge */}
    <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-[#0B1020] border border-white/15 shadow-[0_0_24px_rgba(0,229,255,0.32)] group-hover:shadow-[0_0_32px_rgba(0,229,255,0.55)] transition-shadow duration-300">
      <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-[#00E5FF]/20 via-transparent to-[#7C3AED]/25 pointer-events-none" />
      <svg
        width="22"
        height="22"
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="relative z-10"
        aria-hidden="true"
      >
        <defs>
          <linearGradient id="vidgenGrad" x1="2" y1="2" x2="22" y2="22" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#00E5FF" />
            <stop offset="55%" stopColor="#3B82F6" />
            <stop offset="100%" stopColor="#A855F7" />
          </linearGradient>
        </defs>
        {/* Outer precision frame */}
        <rect
          x="2.5"
          y="3.5"
          width="19"
          height="17"
          rx="4.5"
          stroke="url(#vidgenGrad)"
          strokeWidth="1.75"
        />
        {/* Dynamic motion play prism */}
        <path
          d="M9.5 8.25L16.25 12L9.5 15.75V8.25Z"
          fill="url(#vidgenGrad)"
        />
        {/* Motion trail accent lines */}
        <path
          d="M5.75 9.5H7.25M5.25 12H7.25M5.75 14.5H7.25"
          stroke="#00E5FF"
          strokeWidth="1.4"
          strokeLinecap="round"
        />
      </svg>
    </div>

    <div className="flex items-baseline tracking-tight">
      <span className="font-heading text-lg font-bold text-[#F8FAFC]">VidGen</span>
      <span className="font-heading text-lg font-bold bg-gradient-to-r from-[#00E5FF] to-[#A855F7] bg-clip-text text-transparent">
        .ai
      </span>
    </div>
  </div>
);

export const Navbar: React.FC<NavbarProps> = ({
  onOpenAuth,
  onFocusStudio,
  onOpenApiModal,
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 14);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const navItems = [
    { label: "Features", href: "#features" },
    { label: "Showcase", href: "#showcase" },
    { label: "Models", href: "#models" },
    { label: "Pricing", href: "#pricing" },
    { label: "API Docs", href: "#api-docs", isApi: true },
  ];

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all duration-300 ${
        scrolled
          ? "bg-[#05070C]/85 backdrop-blur-xl border-b border-white/[0.09] shadow-[0_10px_30px_-10px_rgba(0,0,0,0.75)]"
          : "bg-[#05070C]/60 backdrop-blur-md border-b border-white/[0.05]"
      }`}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Brand Logo */}
        <a href="#" className="focus:outline-none">
          <VidGenLogo />
        </a>

        {/* Desktop Nav Links */}
        <nav className="hidden md:flex items-center gap-1 lg:gap-2" aria-label="Primary Navigation">
          {navItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              onClick={(e) => {
                if (item.isApi) {
                  const el = document.getElementById("api-docs");
                  if (!el) {
                    e.preventDefault();
                    onOpenApiModal();
                  }
                }
              }}
              className="rounded-lg px-3.5 py-2 text-sm font-medium text-[#94A3B8] hover:text-[#F8FAFC] hover:bg-white/[0.04] transition-colors"
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* Desktop Actions */}
        <div className="hidden md:flex items-center gap-3">
          <button
            type="button"
            onClick={() => onOpenAuth("signin")}
            className="rounded-xl px-4 py-2 text-sm font-medium text-[#CBD5E1] hover:text-white border border-transparent hover:border-white/10 hover:bg-white/[0.04] transition-all cursor-pointer"
          >
            Sign In
          </button>

          <button
            type="button"
            onClick={onFocusStudio}
            className="btn-glow-gradient inline-flex items-center gap-1.5 rounded-xl px-4 py-2.5 text-sm font-semibold text-white cursor-pointer"
          >
            <span>Generate Free Video</span>
            <ArrowUpRight className="h-4 w-4 stroke-[2.25]" />
          </button>
        </div>

        {/* Mobile Menu Toggle */}
        <button
          type="button"
          onClick={() => setMobileOpen(!mobileOpen)}
          className="inline-flex md:hidden items-center justify-center rounded-lg p-2 text-[#94A3B8] hover:bg-white/5 hover:text-white transition-colors"
          aria-label="Toggle Menu"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="md:hidden border-b border-white/10 bg-[#080C17]/95 backdrop-blur-2xl px-4 pt-3 pb-5 space-y-3">
          <div className="flex flex-col space-y-1">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm font-medium text-[#CBD5E1] hover:bg-white/5 hover:text-[#00E5FF] transition-colors"
              >
                {item.label}
              </a>
            ))}
          </div>
          <div className="pt-2 border-t border-white/10 flex flex-col gap-2.5">
            <button
              type="button"
              onClick={() => {
                setMobileOpen(false);
                onOpenAuth("signin");
              }}
              className="w-full rounded-xl border border-white/15 bg-white/[0.03] py-2.5 text-sm font-medium text-white"
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileOpen(false);
                onFocusStudio();
              }}
              className="btn-glow-gradient w-full inline-flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-sm font-semibold text-white"
            >
              <span>Generate Free Video</span>
              <ArrowUpRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
