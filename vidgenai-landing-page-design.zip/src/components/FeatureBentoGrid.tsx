import React, { useState } from "react";
import {
  Sparkles,
  Image as ImageIcon,
  Camera,
  Maximize,
  UserCheck,
  Terminal,
  Copy,
  Check,
  Lock,
  MoveHorizontal,
  ArrowUpRight,
} from "lucide-react";
import { ACTOR_LOCK_SCENES } from "../data/studioData";

interface FeatureBentoGridProps {
  onOpenApiModal: () => void;
}

type CameraRigMode = "Zoom" | "Pan" | "Tilt" | "Orbit" | "Crane";

export const FeatureBentoGrid: React.FC<FeatureBentoGridProps> = ({ onOpenApiModal }) => {
  // Card 2 state: Before/After split slider
  const [splitPercent, setSplitPercent] = useState<number>(52);

  // Card 3 state: Camera Director Controls
  const [camMode, setCamMode] = useState<CameraRigMode>("Orbit");

  // Card 4 state: 4K toggle
  const [upscaleActive, setUpscaleActive] = useState<boolean>(true);

  // Card 5 state: Actor Lock selected scene
  const [selectedSceneIdx, setSelectedSceneIdx] = useState<number>(0);

  // Card 6 state: SDK language & copy
  const [sdkLang, setSdkLang] = useState<"node" | "python">("node");
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  const codeSnippets = {
    node: `const clip = await vidgen.videos.generate({
  model: "vidgen-v3-ultra",
  prompt: "Cyberpunk alley rain, 4k orbit",
  fps: 60, resolution: "4k",
  webhook_url: "https://api.app.io/hook"
});`,
    python: `clip = client.videos.generate(
    model="vidgen-v3-ultra",
    prompt="Cyberpunk alley rain, 4k orbit",
    fps=60, resolution="4k",
    webhook_url="https://api.app.io/hook"
)`,
  };

  const handleCopySdk = () => {
    navigator.clipboard.writeText(codeSnippets[sdkLang]);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 1800);
  };

  const cameraTelemetry: Record<
    CameraRigMode,
    { vector: string; focal: string; transformClass: string; pathD: string }
  > = {
    Zoom: {
      vector: "Z-Axis +1.85x Push",
      focal: "24mm → 70mm",
      transformClass: "scale-115",
      pathD: "M 30 72 L 150 28",
    },
    Pan: {
      vector: "X-Axis +18.0° Sweep",
      focal: "35mm Anamorphic",
      transformClass: "translate-x-3",
      pathD: "M 22 50 L 158 50",
    },
    Tilt: {
      vector: "Y-Axis +12.5° Pitch",
      focal: "50mm Prime",
      transformClass: "-translate-y-2",
      pathD: "M 90 80 L 90 20",
    },
    Orbit: {
      vector: "360° Arc • Radius 4m",
      focal: "40mm Cinema",
      transformClass: "rotate-3 scale-105",
      pathD: "M 24 62 Q 90 12 156 62",
    },
    Crane: {
      vector: "Jib Rise +4.5m Boom",
      focal: "28mm Wide",
      transformClass: "-translate-y-2.5 translate-x-1.5",
      pathD: "M 28 76 C 65 76, 115 24, 154 24",
    },
  };

  return (
    <section id="features" className="relative py-24 sm:py-28">
      {/* Subtle background glow */}
      <div
        className="pointer-events-none absolute top-1/3 left-1/2 -translate-x-1/2 h-[480px] w-[860px] rounded-full opacity-20 blur-[140px]"
        style={{
          background:
            "radial-gradient(circle, rgba(124,58,237,0.45) 0%, rgba(0,229,255,0.28) 55%, transparent 75%)",
        }}
      />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mx-auto max-w-3xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-[#00E5FF]/25 bg-[#00E5FF]/[0.07] px-3.5 py-1 font-mono text-xs font-medium text-[#00E5FF] mb-4">
            <span>STUDIO ARCHITECTURE</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-[44px] font-bold tracking-[-0.025em] leading-[1.12] text-[#F8FAFC]">
            Full-Stack Motion Control.{" "}
            <span className="bg-gradient-to-r from-[#00E5FF] to-[#A855F7] bg-clip-text text-transparent">
              Zero 3D Complexity.
            </span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#94A3B8]">
            Every tool a modern VFX supervisor, growth marketer, or AI engineer needs to direct
            frame-accurate 4K cinema inside the browser or via REST API.
          </p>
        </div>

        {/* 3x2 Symmetrical Bento Grid */}
        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* CARD 1: Text-to-Video */}
          <div className="glass-card rounded-2xl p-6 sm:p-7 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="inline-flex items-center gap-1.5 rounded-lg bg-[#00E5FF]/10 border border-[#00E5FF]/25 px-2.5 py-1 font-mono text-[11px] font-medium text-[#00E5FF]">
                  <Sparkles className="h-3.5 w-3.5" />
                  Text-to-Video
                </span>
                <span className="font-mono text-[11px] text-[#64748B]">PHYSICS v3</span>
              </div>

              <h3 className="font-heading text-xl font-bold text-[#F8FAFC]">
                Natural Language Motion Control
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-[#94A3B8]">
                Type simple descriptive prompts and let AI calculate physics, lighting, and camera
                paths automatically.
              </p>
            </div>

            {/* Micro-UI: Semantic Prompt Tokenizer + Motion Spline */}
            <div className="mt-6 rounded-xl border border-white/[0.08] bg-[#05070C]/85 p-4 space-y-3">
              <div className="text-xs leading-relaxed text-[#CBD5E1] font-mono">
                &ldquo;Raindrops splashing on{" "}
                <span className="rounded bg-[#00E5FF]/15 border border-[#00E5FF]/35 px-1.5 py-0.5 text-[#00E5FF]">
                  neon asphalt
                </span>
                ,{" "}
                <span className="rounded bg-[#7C3AED]/20 border border-[#A855F7]/35 px-1.5 py-0.5 text-[#C084FC]">
                  slow-motion 60fps
                </span>
                ,{" "}
                <span className="rounded bg-[#10B981]/15 border border-[#10B981]/35 px-1.5 py-0.5 text-[#34D399]">
                  low dolly push
                </span>
                &rdquo;
              </div>

              <div className="pt-2 border-t border-white/[0.06] grid grid-cols-3 gap-2 font-mono text-[10px]">
                <div className="rounded-lg bg-white/[0.03] p-2">
                  <div className="text-[#64748B]">RAYTRACING</div>
                  <div className="text-[#00E5FF] font-semibold mt-0.5">SSR + Caustics</div>
                </div>
                <div className="rounded-lg bg-white/[0.03] p-2">
                  <div className="text-[#64748B]">GRAVITY</div>
                  <div className="text-[#C084FC] font-semibold mt-0.5">9.8m/s² Fluid</div>
                </div>
                <div className="rounded-lg bg-white/[0.03] p-2">
                  <div className="text-[#64748B]">TRAJECTORY</div>
                  <div className="text-[#34D399] font-semibold mt-0.5">6-DoF Solved</div>
                </div>
              </div>
            </div>
          </div>

          {/* CARD 2: Image-to-Video */}
          <div className="glass-card rounded-2xl p-6 sm:p-7 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="inline-flex items-center gap-1.5 rounded-lg bg-[#7C3AED]/15 border border-[#A855F7]/30 px-2.5 py-1 font-mono text-[11px] font-medium text-[#C084FC]">
                  <ImageIcon className="h-3.5 w-3.5" />
                  Image-to-Video
                </span>
                <span className="font-mono text-[11px] text-[#64748B]">PNG • FIGMA • RAW</span>
              </div>

              <h3 className="font-heading text-xl font-bold text-[#F8FAFC]">
                Animate Any Static Artwork
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-[#94A3B8]">
                Upload any PNG or Figma design and bring static photos or concept art to life with
                realistic motion.
              </p>
            </div>

            {/* Micro-UI: Interactive Static PNG vs Live Motion Split Slider */}
            <div className="mt-6">
              <div className="relative h-36 w-full overflow-hidden rounded-xl border border-white/10 select-none bg-[#05070C]">
                {/* Right Layer: Animated Live Video */}
                <video
                  src="https://videos.pexels.com/video-files/32822471/13990568_3840_2160_24fps.mp4"
                  poster="https://images.pexels.com/videos/32822471/science-fiction-skayline-32822471.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200"
                  autoPlay
                  muted
                  loop
                  playsInline
                  className="absolute inset-0 h-full w-full object-cover"
                />
                <span className="absolute top-2.5 right-2.5 z-10 rounded bg-[#00E5FF]/20 border border-[#00E5FF]/40 backdrop-blur-md px-2 py-0.5 font-mono text-[10px] font-semibold text-[#00E5FF]">
                  AI MOTION
                </span>

                {/* Left Clipped Layer: Static Concept Frame with Figma Wireframe */}
                <div
                  className="absolute inset-y-0 left-0 overflow-hidden border-r-2 border-[#00E5FF]"
                  style={{ width: `${splitPercent}%` }}
                >
                  <img
                    src="https://images.pexels.com/videos/32822471/science-fiction-skayline-32822471.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200"
                    alt="Static Concept Art PNG"
                    className="h-full w-96 max-w-none object-cover grayscale-[35%] contrast-95"
                  />
                  <div className="absolute inset-2 border border-dashed border-white/40 rounded pointer-events-none" />
                  <span className="absolute top-2.5 left-2.5 rounded bg-[#05070C]/80 border border-white/20 px-2 py-0.5 font-mono text-[10px] text-[#CBD5E1]">
                    STATIC.PNG
                  </span>
                </div>

                {/* Drag Handle Visual */}
                <div
                  className="pointer-events-none absolute top-1/2 -translate-y-1/2 -translate-x-1/2 z-20 flex h-7 w-7 items-center justify-center rounded-full bg-[#00E5FF] text-[#05070C] shadow-[0_0_16px_rgba(0,229,255,0.9)]"
                  style={{ left: `${splitPercent}%` }}
                >
                  <MoveHorizontal className="h-3.5 w-3.5 stroke-[2.5]" />
                </div>

                {/* Invisible Interactive Range Overlay */}
                <input
                  type="range"
                  min={15}
                  max={85}
                  value={splitPercent}
                  onChange={(e) => setSplitPercent(Number(e.target.value))}
                  aria-label="Compare Static PNG vs Animated Video"
                  className="absolute inset-0 z-30 h-full w-full opacity-0 cursor-ew-resize"
                />
              </div>
              <div className="mt-2 flex justify-between font-mono text-[10px] text-[#64748B]">
                <span>← Drag to compare static upload</span>
                <span className="text-[#00E5FF]">Motion synthesized →</span>
              </div>
            </div>
          </div>

          {/* CARD 3: Camera Director Controls */}
          <div className="glass-card rounded-2xl p-6 sm:p-7 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="inline-flex items-center gap-1.5 rounded-lg bg-[#00E5FF]/10 border border-[#00E5FF]/25 px-2.5 py-1 font-mono text-[11px] font-medium text-[#00E5FF]">
                  <Camera className="h-3.5 w-3.5" />
                  Camera Director
                </span>
                <span className="font-mono text-[11px] text-[#64748B]">6-DOF RIG</span>
              </div>

              <h3 className="font-heading text-xl font-bold text-[#F8FAFC]">
                Precision Camera Movements
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-[#94A3B8]">
                Full visual controls for Zoom, Pan, Tilt, Orbit, and Crane shots without complex 3D
                software.
              </p>
            </div>

            {/* Micro-UI: Interactive 5-Axis Camera Rig */}
            <div className="mt-6 rounded-xl border border-white/[0.08] bg-[#05070C]/85 p-3.5">
              {/* SVG Viewport Frustum */}
              <div className="relative h-24 w-full overflow-hidden rounded-lg bg-studio-grid-dense border border-white/[0.06] flex items-center justify-center">
                <svg
                  viewBox="0 0 180 96"
                  className={`h-full w-full transition-transform duration-300 ${cameraTelemetry[camMode].transformClass}`}
                >
                  <defs>
                    <linearGradient id="camPathGrad" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#00E5FF" />
                      <stop offset="100%" stopColor="#A855F7" />
                    </linearGradient>
                  </defs>
                  {/* Perspective wireframe grid */}
                  <polygon
                    points="55,24 125,24 148,74 32,74"
                    fill="rgba(0,229,255,0.05)"
                    stroke="rgba(255,255,255,0.14)"
                    strokeWidth="1"
                  />
                  {/* Dynamic camera trajectory vector */}
                  <path
                    d={cameraTelemetry[camMode].pathD}
                    fill="none"
                    stroke="url(#camPathGrad)"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeDasharray="4 3"
                  />
                  <circle cx="90" cy="48" r="5" fill="#00E5FF" />
                </svg>
                <div className="absolute bottom-1.5 left-2.5 right-2.5 flex justify-between font-mono text-[10px]">
                  <span className="text-[#00E5FF]">{cameraTelemetry[camMode].vector}</span>
                  <span className="text-[#94A3B8]">{cameraTelemetry[camMode].focal}</span>
                </div>
              </div>

              {/* 5 Shot Buttons */}
              <div className="mt-2.5 grid grid-cols-5 gap-1.5">
                {(["Zoom", "Pan", "Tilt", "Orbit", "Crane"] as CameraRigMode[]).map((mode) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => setCamMode(mode)}
                    className={`rounded-md py-1.5 font-mono text-[11px] font-medium transition-all cursor-pointer ${
                      camMode === mode
                        ? "bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/45"
                        : "bg-white/[0.03] text-[#94A3B8] hover:text-white border border-transparent"
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* CARD 4: 4K Upscaling & Interpolation */}
          <div className="glass-card rounded-2xl p-6 sm:p-7 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="inline-flex items-center gap-1.5 rounded-lg bg-[#7C3AED]/15 border border-[#A855F7]/30 px-2.5 py-1 font-mono text-[11px] font-medium text-[#C084FC]">
                  <Maximize className="h-3.5 w-3.5" />
                  Super-Resolution
                </span>
                <span className="font-mono text-[11px] text-[#10B981]">3840 × 2160</span>
              </div>

              <h3 className="font-heading text-xl font-bold text-[#F8FAFC]">
                Studio-Grade Resolution
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-[#94A3B8]">
                Native 60FPS frame interpolation and built-in 4K upscaling for crystal-clear
                playback.
              </p>
            </div>

            {/* Micro-UI: 4K Upscaling & 60FPS Optical Flow Pipeline */}
            <div className="mt-6 rounded-xl border border-white/[0.08] bg-[#05070C]/85 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[11px] text-[#94A3B8]">OPTICAL FLOW ENGINE</span>
                <button
                  type="button"
                  onClick={() => setUpscaleActive(!upscaleActive)}
                  className={`rounded-full px-2.5 py-0.5 font-mono text-[10px] font-semibold transition-all cursor-pointer ${
                    upscaleActive
                      ? "bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/40"
                      : "bg-white/10 text-[#94A3B8]"
                  }`}
                >
                  {upscaleActive ? "4K 60FPS ON" : "720p 24FPS RAW"}
                </button>
              </div>

              {/* Frame Interpolation Strip */}
              <div className="grid grid-cols-5 gap-1.5 items-center">
                {["F01", "AI+1", "F02", "AI+2", "F03"].map((frame, i) => {
                  const isInterpolated = i % 2 === 1;
                  return (
                    <div
                      key={frame}
                      className={`rounded-lg py-2.5 text-center font-mono text-[10px] transition-all ${
                        isInterpolated
                          ? upscaleActive
                            ? "border border-[#00E5FF]/50 bg-gradient-to-b from-[#00E5FF]/20 to-[#7C3AED]/20 text-[#00E5FF] shadow-[0_0_12px_rgba(0,229,255,0.2)]"
                            : "border border-dashed border-white/10 bg-white/[0.02] text-[#475569] opacity-45"
                          : "border border-white/10 bg-white/[0.04] text-[#CBD5E1]"
                      }`}
                    >
                      {frame}
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-between font-mono text-[11px] pt-1">
                <span className="text-[#64748B]">Bitrate Output</span>
                <span className="text-[#F8FAFC] tabular-nums">
                  {upscaleActive ? "85 Mbps • ProRes / MP4" : "12 Mbps • Draft"}
                </span>
              </div>
            </div>
          </div>

          {/* CARD 5: Character Consistency */}
          <div className="glass-card rounded-2xl p-6 sm:p-7 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="inline-flex items-center gap-1.5 rounded-lg bg-[#00E5FF]/10 border border-[#00E5FF]/25 px-2.5 py-1 font-mono text-[11px] font-medium text-[#00E5FF]">
                  <UserCheck className="h-3.5 w-3.5" />
                  Identity Lock
                </span>
                <span className="inline-flex items-center gap-1 font-mono text-[11px] text-[#10B981]">
                  <Lock className="h-3 w-3" />
                  ACTOR #VG-09
                </span>
              </div>

              <h3 className="font-heading text-xl font-bold text-[#F8FAFC]">
                Consistent Actor Lock
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-[#94A3B8]">
                Maintain the exact same facial structure, outfit, and character details across
                multiple generated scenes.
              </p>
            </div>

            {/* Micro-UI: 3 Multi-Scene Locked Character Thumbnails */}
            <div className="mt-6 space-y-2.5">
              <div className="grid grid-cols-3 gap-2">
                {ACTOR_LOCK_SCENES.map((scene, idx) => {
                  const active = idx === selectedSceneIdx;
                  return (
                    <button
                      key={scene.id}
                      type="button"
                      onClick={() => setSelectedSceneIdx(idx)}
                      className={`group relative overflow-hidden rounded-xl border transition-all cursor-pointer ${
                        active
                          ? "border-[#00E5FF] ring-2 ring-[#00E5FF]/25"
                          : "border-white/10 opacity-75 hover:opacity-100"
                      }`}
                    >
                      <img
                        src={scene.imageUrl}
                        alt={scene.location}
                        className="h-24 w-full object-cover"
                      />
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#05070C] via-[#05070C]/80 to-transparent p-1.5 text-left">
                        <div className="font-mono text-[9px] font-semibold text-[#00E5FF]">
                          {scene.sceneCode}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center justify-between rounded-lg border border-white/[0.07] bg-[#05070C]/80 px-3 py-2 font-mono text-[11px]">
                <span className="text-[#CBD5E1]">{ACTOR_LOCK_SCENES[selectedSceneIdx].location}</span>
                <span className="text-[#10B981] font-semibold tabular-nums">
                  {ACTOR_LOCK_SCENES[selectedSceneIdx].matchScore} Match
                </span>
              </div>
            </div>
          </div>

          {/* CARD 6: Developer API & Webhooks */}
          <div
            id="api-docs"
            className="glass-card rounded-2xl p-6 sm:p-7 flex flex-col justify-between scroll-mt-24"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="inline-flex items-center gap-1.5 rounded-lg bg-[#7C3AED]/15 border border-[#A855F7]/30 px-2.5 py-1 font-mono text-[11px] font-medium text-[#C084FC]">
                  <Terminal className="h-3.5 w-3.5" />
                  REST API &amp; SDKs
                </span>
                <button
                  type="button"
                  onClick={onOpenApiModal}
                  className="inline-flex items-center gap-1 font-mono text-[11px] text-[#00E5FF] hover:underline cursor-pointer"
                >
                  <span>API Docs</span>
                  <ArrowUpRight className="h-3 w-3" />
                </button>
              </div>

              <h3 className="font-heading text-xl font-bold text-[#F8FAFC]">
                Built for Developers
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-[#94A3B8]">
                REST API endpoints and Python/Node SDKs to generate videos programmatically inside
                your own apps.
              </p>
            </div>

            {/* Micro-UI: Interactive Dark Code Terminal */}
            <div className="mt-6 rounded-xl border border-white/10 bg-[#04060B] overflow-hidden">
              <div className="flex items-center justify-between border-b border-white/[0.08] bg-[#090D18] px-3 py-2">
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setSdkLang("node")}
                    className={`rounded px-2 py-0.5 font-mono text-[10px] font-medium cursor-pointer ${
                      sdkLang === "node"
                        ? "bg-[#00E5FF]/15 text-[#00E5FF]"
                        : "text-[#64748B] hover:text-white"
                    }`}
                  >
                    Node.js
                  </button>
                  <button
                    type="button"
                    onClick={() => setSdkLang("python")}
                    className={`rounded px-2 py-0.5 font-mono text-[10px] font-medium cursor-pointer ${
                      sdkLang === "python"
                        ? "bg-[#00E5FF]/15 text-[#00E5FF]"
                        : "text-[#64748B] hover:text-white"
                    }`}
                  >
                    Python
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleCopySdk}
                  className="inline-flex items-center gap-1 font-mono text-[10px] text-[#94A3B8] hover:text-white cursor-pointer"
                >
                  {copiedCode ? (
                    <>
                      <Check className="h-3 w-3 text-[#10B981]" />
                      <span className="text-[#10B981]">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>

              <pre className="p-3 font-mono text-[11px] leading-relaxed text-[#CBD5E1] overflow-x-auto">
                <code>{codeSnippets[sdkLang]}</code>
              </pre>

              <div className="flex items-center justify-between border-t border-white/[0.06] bg-[#080C16] px-3 py-1.5 font-mono text-[10px]">
                <span className="text-[#10B981]">● 200 OK • webhook.delivered</span>
                <span className="text-[#64748B] tabular-nums">790ms</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
