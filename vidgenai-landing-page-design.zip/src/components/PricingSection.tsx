import React, { useState } from "react";
import { Check, Sparkles, Zap } from "lucide-react";
import { PRICING_TIERS } from "../data/studioData";

interface PricingSectionProps {
  onSelectPlan: (planName: string, billing: "monthly" | "annual") => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onSelectPlan }) => {
  const [billing, setBilling] = useState<"annual" | "monthly">("annual");

  return (
    <section id="pricing" className="relative py-24 sm:py-28 scroll-mt-16">
      {/* Controlled radial glow behind Pro Studio */}
      <div
        className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-[500px] w-[760px] rounded-full opacity-25 blur-[140px]"
        style={{
          background:
            "radial-gradient(circle, rgba(0,229,255,0.35) 0%, rgba(124,58,237,0.35) 55%, transparent 75%)",
        }}
      />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mx-auto max-w-3xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-[#00E5FF]/25 bg-[#00E5FF]/[0.07] px-3.5 py-1 font-mono text-xs font-medium text-[#00E5FF] mb-4">
            <span>PREDICTABLE GPU PRICING</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-[44px] font-bold tracking-[-0.025em] leading-[1.12] text-[#F8FAFC]">
            Transparent Studio Plans.{" "}
            <span className="bg-gradient-to-r from-[#00E5FF] to-[#A855F7] bg-clip-text text-transparent">
              Scale on Demand.
            </span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#94A3B8]">
            Start free with 50 render credits. Upgrade anytime for native 4K 60FPS output, priority
            H200 queues, and full commercial licensing.
          </p>

          {/* Monthly / Annual Billing Toggle */}
          <div className="mt-8 inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-[#0B1020]/90 p-1.5 backdrop-blur-xl">
            <button
              type="button"
              onClick={() => setBilling("monthly")}
              className={`rounded-xl px-5 py-2.5 text-sm font-semibold transition-all cursor-pointer ${
                billing === "monthly"
                  ? "bg-white/10 text-white shadow-sm"
                  : "text-[#94A3B8] hover:text-white"
              }`}
            >
              Monthly
            </button>

            <button
              type="button"
              onClick={() => setBilling("annual")}
              className={`inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold transition-all cursor-pointer ${
                billing === "annual"
                  ? "bg-gradient-to-r from-[#00E5FF]/20 to-[#7C3AED]/25 text-white border border-[#00E5FF]/40 shadow-[0_0_20px_-4px_rgba(0,229,255,0.35)]"
                  : "text-[#94A3B8] hover:text-white"
              }`}
            >
              <span>Annual</span>
              <span className="rounded-full bg-[#10B981]/20 border border-[#10B981]/40 px-2 py-0.5 font-mono text-[11px] font-semibold text-[#34D399]">
                Save 20%
              </span>
            </button>
          </div>
        </div>

        {/* 3-Column Pricing Grid */}
        <div className="mt-14 grid grid-cols-1 lg:grid-cols-3 gap-7 items-stretch">
          {PRICING_TIERS.map((tier) => {
            const displayPrice = billing === "annual" ? tier.annualPrice : tier.monthlyPrice;
            const isPopular = Boolean(tier.popular);

            return (
              <div
                key={tier.id}
                className={`relative rounded-3xl flex flex-col justify-between transition-all duration-300 ${
                  isPopular
                    ? "p-[1.5px] bg-gradient-to-b from-[#00E5FF] via-[#3B82F6]/60 to-[#7C3AED] shadow-[0_24px_80px_-16px_rgba(0,229,255,0.28)] lg:-translate-y-2"
                    : "border border-white/10 bg-[#0A0F1D]/85 hover:border-white/20"
                }`}
              >
                {/* Most Popular Floating Pill */}
                {isPopular && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 z-10">
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-[#00E5FF] to-[#7C3AED] px-4 py-1 text-xs font-bold uppercase tracking-wider text-[#05070C] shadow-[0_0_24px_rgba(0,229,255,0.6)]">
                      <Sparkles className="h-3.5 w-3.5 fill-current" />
                      Most Popular
                    </span>
                  </div>
                )}

                <div
                  className={`h-full rounded-[22.5px] p-7 sm:p-8 flex flex-col justify-between ${
                    isPopular ? "bg-[#090E1B]/95 backdrop-blur-2xl" : ""
                  }`}
                >
                  <div>
                    {/* Plan Name & Credits Pill */}
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="font-heading text-2xl font-bold text-[#F8FAFC]">
                        {tier.name}
                      </h3>
                      <span
                        className={`rounded-lg px-2.5 py-1 font-mono text-[11px] font-medium ${
                          isPopular
                            ? "bg-[#00E5FF]/15 text-[#00E5FF] border border-[#00E5FF]/30"
                            : "bg-white/[0.04] text-[#94A3B8] border border-white/10"
                        }`}
                      >
                        {tier.creditsBadge}
                      </span>
                    </div>

                    <p className="mt-2.5 text-sm text-[#94A3B8] leading-relaxed">{tier.tagline}</p>

                    {/* Price Block */}
                    <div className="mt-6 pb-6 border-b border-white/[0.08]">
                      <div className="flex items-baseline gap-2">
                        <span className="font-heading text-5xl font-bold tracking-tight text-[#F8FAFC] tabular-nums">
                          ${displayPrice}
                        </span>
                        <span className="text-sm font-medium text-[#94A3B8]">/mo</span>
                        {billing === "annual" && (
                          <span className="ml-1 font-mono text-sm text-[#64748B] line-through tabular-nums">
                            ${tier.monthlyPrice}/mo
                          </span>
                        )}
                      </div>
                      <p className="mt-1.5 font-mono text-xs text-[#64748B]">
                        {billing === "annual"
                          ? tier.annualNote
                          : `Billed monthly ($${tier.monthlyPrice}/mo) • Switch to annual for 20% off`}
                      </p>
                    </div>

                    {/* Feature Checklist */}
                    <ul className="mt-6 space-y-3.5">
                      {tier.features.map((feature) => (
                        <li key={feature} className="flex items-start gap-3 text-sm text-[#CBD5E1]">
                          <span
                            className={`mt-0.5 inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${
                              isPopular
                                ? "bg-[#00E5FF]/20 text-[#00E5FF]"
                                : "bg-white/[0.07] text-[#94A3B8]"
                            }`}
                          >
                            <Check className="h-3.5 w-3.5 stroke-[2.5]" />
                          </span>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Plan CTA Button */}
                  <div className="mt-8 pt-2">
                    <button
                      type="button"
                      onClick={() => onSelectPlan(tier.name, billing)}
                      className={`w-full inline-flex items-center justify-center gap-2 rounded-xl py-3.5 px-5 text-sm font-semibold transition-all cursor-pointer ${
                        isPopular
                          ? "btn-glow-gradient text-white"
                          : "border border-white/15 bg-white/[0.04] hover:bg-white/[0.09] hover:border-[#00E5FF]/40 text-[#F8FAFC]"
                      }`}
                    >
                      {isPopular && <Zap className="h-4 w-4" />}
                      <span>{tier.ctaLabel}</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
