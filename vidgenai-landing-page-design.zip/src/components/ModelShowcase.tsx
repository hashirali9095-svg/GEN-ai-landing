import React, { useState } from "react";
import {
  Film,
  ShoppingBag,
  Box,
  Sparkles,
  Clock,
  Copy,
  Check,
  ArrowUpRight,
  Cpu,
  Hash,
} from "lucide-react";
import { SHOWCASE_CATEGORIES, ShowcaseCardItem, StudioPreset } from "../data/studioData";

interface ModelShowcaseProps {
  onLoadIntoStudio: (preset: StudioPreset) => void;
}

export const ModelShowcase: React.FC<ModelShowcaseProps> = ({ onLoadIntoStudio }) => {
  const [activeTabId, setActiveTabId] = useState<string>(SHOWCASE_CATEGORIES[0].id);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const activeCategory =
    SHOWCASE_CATEGORIES.find((cat) => cat.id === activeTabId) || SHOWCASE_CATEGORIES[0];

  const tabIcons: Record<string, React.ReactNode> = {
    cinematic: <Film className="h-4 w-4" />,
    ecommerce: <ShoppingBag className="h-4 w-4" />,
    "anime-3d": <Box className="h-4 w-4" />,
    vfx: <Sparkles className="h-4 w-4" />,
  };

  const handleCopyPrompt = (card: ShowcaseCardItem) => {
    navigator.clipboard.writeText(card.prompt);
    setCopiedId(card.id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const handleSendToHero = (card: ShowcaseCardItem) => {
    const mappedPreset: StudioPreset = {
      id: card.id,
      label: card.title,
      prompt: card.prompt,
      videoUrl: card.videoUrl,
      posterUrl: card.posterUrl,
      seed: parseInt(card.seed, 10) || 40928174,
      renderTime: card.generationTime,
      motionStrength: parseFloat(card.motionScore) || 8.0,
      fps: card.resolution.includes("24") ? 24 : 60,
      cameraControl: 2.5,
      cameraMode: card.cameraTag,
      model: card.modelBadge,
      resolution: "3840 × 2160 • " + card.resolution,
    };
    onLoadIntoStudio(mappedPreset);
  };

  return (
    <section
      id="showcase"
      className="relative border-t border-white/[0.07] bg-[#060912] py-24 sm:py-28 scroll-mt-16"
    >
      <div id="models" className="scroll-mt-24" />

      {/* Subtle Ambient Glow */}
      <div
        className="pointer-events-none absolute top-24 right-1/4 h-[420px] w-[620px] rounded-full opacity-20 blur-[140px]"
        style={{
          background: "radial-gradient(circle, rgba(0,229,255,0.38) 0%, transparent 70%)",
        }}
      />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mx-auto max-w-3xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-[#A855F7]/30 bg-[#7C3AED]/10 px-3.5 py-1 font-mono text-xs font-medium text-[#C084FC] mb-4">
            <Cpu className="h-3.5 w-3.5" />
            <span>SPECIALIZED MOTION MODELS</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-[44px] font-bold tracking-[-0.025em] leading-[1.12] text-[#F8FAFC]">
            Interactive Prompt &amp;{" "}
            <span className="bg-gradient-to-r from-[#00E5FF] to-[#A855F7] bg-clip-text text-transparent">
              Model Showcase
            </span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#94A3B8]">
            Inspect real prompts, deterministic seeds, and exact H200 render latencies across our
            four specialized v3.0 motion checkpoints.
          </p>
        </div>

        {/* Tabbed Segmented Navigation */}
        <div className="mt-10 flex justify-center">
          <div
            role="tablist"
            aria-label="Video Model Categories"
            className="inline-flex flex-wrap items-center justify-center gap-1.5 rounded-2xl border border-white/10 bg-[#0B1020]/90 p-1.5 backdrop-blur-xl"
          >
            {SHOWCASE_CATEGORIES.map((category) => {
              const isSelected = category.id === activeTabId;
              return (
                <button
                  key={category.id}
                  role="tab"
                  aria-selected={isSelected}
                  type="button"
                  onClick={() => setActiveTabId(category.id)}
                  className={`inline-flex items-center gap-2 rounded-xl px-4 sm:px-5 py-2.5 text-sm font-semibold transition-all cursor-pointer ${
                    isSelected
                      ? "bg-gradient-to-r from-[#00E5FF]/20 via-[#3B82F6]/20 to-[#7C3AED]/25 text-white border border-[#00E5FF]/45 shadow-[0_0_24px_-4px_rgba(0,229,255,0.35)]"
                      : "text-[#94A3B8] hover:text-white border border-transparent hover:bg-white/[0.04]"
                  }`}
                >
                  <span className={isSelected ? "text-[#00E5FF]" : "text-[#64748B]"}>
                    {tabIcons[category.id]}
                  </span>
                  <span>{category.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Model Telemetry Strip */}
        <div className="mt-6 mx-auto max-w-4xl flex flex-col sm:flex-row items-center justify-between gap-3 rounded-xl border border-white/[0.07] bg-[#0A0F1D]/80 px-5 py-3 text-xs">
          <div className="flex items-center gap-2.5">
            <span className="inline-flex h-2 w-2 rounded-full bg-[#00E5FF]" />
            <span className="font-mono font-semibold text-[#F8FAFC]">
              {activeCategory.modelName}
            </span>
            <span className="hidden md:inline text-white/20">•</span>
            <span className="hidden md:inline text-[#94A3B8]">{activeCategory.description}</span>
          </div>
          <span className="shrink-0 rounded-md bg-[#10B981]/10 border border-[#10B981]/30 px-2.5 py-1 font-mono text-[11px] text-[#34D399] tabular-nums">
            ⚡ {activeCategory.latencyAvg}
          </span>
        </div>

        {/* Side-by-Side Prompt Cards (2 Columns) */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-7">
          {activeCategory.cards.map((card) => (
            <article
              key={card.id}
              className="group glass-card rounded-2xl overflow-hidden flex flex-col justify-between"
            >
              {/* Video Preview Container (16:9) */}
              <div className="relative aspect-video w-full overflow-hidden bg-[#04060B]">
                <video
                  key={card.videoUrl}
                  src={card.videoUrl}
                  poster={card.posterUrl}
                  autoPlay
                  muted
                  loop
                  playsInline
                  className="h-full w-full object-cover group-hover:scale-[1.03] transition-transform duration-500"
                />
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#090D1A] via-transparent to-black/35 opacity-85" />

                {/* Top Badges */}
                <div className="absolute top-3.5 left-3.5 right-3.5 flex items-center justify-between gap-2">
                  <span className="rounded-lg bg-[#05070C]/80 border border-white/15 backdrop-blur-md px-2.5 py-1 font-mono text-[11px] font-medium text-[#00E5FF]">
                    {card.modelBadge}
                  </span>

                  <span className="inline-flex items-center gap-1.5 rounded-lg bg-[#05070C]/85 border border-[#10B981]/40 backdrop-blur-md px-2.5 py-1 font-mono text-[11px] font-semibold text-[#34D399] tabular-nums">
                    <Clock className="h-3 w-3" />
                    Gen Time: {card.generationTime}
                  </span>
                </div>

                {/* Bottom Title & Resolution Overlay */}
                <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between">
                  <div>
                    <h3 className="font-heading text-lg font-bold text-white drop-shadow">
                      {card.title}
                    </h3>
                  </div>
                  <span className="rounded bg-white/10 backdrop-blur-md px-2 py-0.5 font-mono text-[10px] font-semibold text-white tabular-nums">
                    {card.resolution}
                  </span>
                </div>
              </div>

              {/* Prompt & Deterministic Seed Telemetry */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-5">
                {/* Exact Prompt Box */}
                <div className="rounded-xl border border-white/[0.08] bg-[#05070C]/90 p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-[10px] uppercase tracking-wider text-[#64748B]">
                      EXACT INPUT PROMPT
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopyPrompt(card)}
                      className="inline-flex items-center gap-1 font-mono text-[11px] text-[#94A3B8] hover:text-[#00E5FF] transition-colors cursor-pointer"
                    >
                      {copiedId === card.id ? (
                        <>
                          <Check className="h-3 w-3 text-[#10B981]" />
                          <span className="text-[#10B981]">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-3 w-3" />
                          <span>Copy Prompt</span>
                        </>
                      )}
                    </button>
                  </div>
                  <p className="text-sm leading-relaxed text-[#E2E8F0] font-normal">
                    &ldquo;{card.prompt}&rdquo;
                  </p>
                </div>

                {/* Seed Settings & Action Footer */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                  <div className="flex flex-wrap items-center gap-2 font-mono text-[11px] tabular-nums">
                    <span className="inline-flex items-center gap-1 rounded-md border border-white/10 bg-white/[0.03] px-2.5 py-1 text-[#CBD5E1]">
                      <Hash className="h-3 w-3 text-[#00E5FF]" />
                      Seed: {card.seed}
                    </span>
                    <span className="rounded-md border border-white/10 bg-white/[0.03] px-2.5 py-1 text-[#94A3B8]">
                      CFG: {card.cfgScale}
                    </span>
                    <span className="rounded-md border border-white/10 bg-white/[0.03] px-2.5 py-1 text-[#94A3B8]">
                      Motion: {card.motionScore}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleSendToHero(card)}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-[#00E5FF]/35 bg-[#00E5FF]/10 hover:bg-[#00E5FF]/20 px-3 py-1.5 text-xs font-semibold text-[#00E5FF] transition-all cursor-pointer"
                  >
                    <span>Try in Studio</span>
                    <ArrowUpRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};
