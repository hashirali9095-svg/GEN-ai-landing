import React from "react";
import { Star } from "lucide-react";

export const SocialProofWall: React.FC = () => {
  const studios = [
    {
      name: "A24 Digital",
      svg: (
        <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <polygon points="12 3 21 20 3 20" />
          <line x1="7.5" y1="14" x2="16.5" y2="14" />
        </svg>
      ),
    },
    {
      name: "Horizon VFX",
      svg: (
        <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <circle cx="12" cy="12" r="8" />
          <path d="M2 12h20" />
          <path d="M6 8.5c3.5-2 8.5-2 12 0" />
        </svg>
      ),
    },
    {
      name: "Motion Lab",
      svg: (
        <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <rect x="3" y="5" width="12" height="14" rx="2.5" />
          <path d="M15 9.5L21 6.5v11l-6-3" />
        </svg>
      ),
    },
    {
      name: "Vertex Studios",
      svg: (
        <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <path d="M12 2L21 7v10l-9 5-9-5V7l9-5z" />
          <path d="M12 22V12M12 12L21 7M12 12L3 7" />
        </svg>
      ),
    },
    {
      name: "Lumina AI",
      svg: (
        <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <path d="M12 2v4M12 18v4M2 12h4M18 12h4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M19.07 4.93l-2.83 2.83M7.76 16.24l-2.83 2.83" />
          <circle cx="12" cy="12" r="3" />
        </svg>
      ),
    },
    {
      name: "Kinetix Frame",
      svg: (
        <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <rect x="3" y="3" width="8" height="8" rx="1.5" />
          <rect x="13" y="3" width="8" height="8" rx="1.5" />
          <rect x="3" y="13" width="8" height="8" rx="1.5" />
          <circle cx="17" cy="17" r="4" />
        </svg>
      ),
    },
  ];

  const stats = [
    {
      value: "12.8M",
      label: "Videos Generated",
      detail: "Across 140+ countries",
      accent: "from-[#00E5FF] to-[#60A5FA]",
    },
    {
      value: "4K 60FPS",
      label: "Output",
      detail: "Native optical interpolation",
      accent: "from-[#F8FAFC] to-[#CBD5E1]",
    },
    {
      value: "0.8s",
      label: "Render Speed",
      detail: "Real-time H200 diffusion",
      accent: "from-[#00E5FF] to-[#A855F7]",
    },
    {
      value: "4.9/5",
      label: "Rating",
      detail: "Verified G2 & Product Hunt",
      accent: "from-[#F8FAFC] to-[#E2E8F0]",
      showStars: true,
    },
  ];

  return (
    <section className="relative border-y border-white/[0.07] bg-[#070A13]/80 py-14 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Heading */}
        <p className="text-center font-mono text-xs sm:text-sm uppercase tracking-[0.14em] text-[#94A3B8]">
          Trusted by 45,000+ film directors, agencies, and digital creators
        </p>

        {/* 6 Modern Creative Studio Logos */}
        <div className="mt-8 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-6 items-center">
          {studios.map((studio) => (
            <div
              key={studio.name}
              className="group flex items-center justify-center gap-2.5 rounded-xl border border-white/[0.05] bg-white/[0.015] hover:bg-white/[0.04] hover:border-white/15 px-4 py-3.5 text-[#94A3B8]/70 hover:text-[#F8FAFC] transition-all duration-200"
            >
              <span className="text-[#94A3B8]/80 group-hover:text-[#00E5FF] transition-colors">
                {studio.svg}
              </span>
              <span className="font-heading text-sm sm:text-[15px] font-semibold tracking-tight">
                {studio.name}
              </span>
            </div>
          ))}
        </div>

        {/* High-Contrast Stats Row */}
        <div className="mt-12 grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="relative overflow-hidden rounded-2xl border border-white/[0.08] bg-[#0B0F1C]/80 p-5 sm:p-6 text-center sm:text-left"
            >
              <div className="flex items-center justify-center sm:justify-between">
                <span
                  className={`font-heading text-3xl sm:text-4xl font-bold tracking-tight tabular-nums bg-gradient-to-r ${stat.accent} bg-clip-text text-transparent`}
                >
                  {stat.value}
                </span>
                {stat.showStars && (
                  <div className="hidden sm:flex items-center gap-0.5 text-[#00E5FF]">
                    {[...Array(5)].map((_, idx) => (
                      <Star key={idx} className="h-3.5 w-3.5 fill-[#00E5FF]" />
                    ))}
                  </div>
                )}
              </div>
              <div className="mt-2 text-sm font-semibold text-[#F8FAFC]">{stat.label}</div>
              <div className="mt-0.5 font-mono text-[11px] text-[#64748B]">{stat.detail}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
