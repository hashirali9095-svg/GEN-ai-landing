import React from "react";
import { ArrowUpRight, Sparkles } from "lucide-react";
import { VidGenLogo } from "./Navbar";

interface FinalCtaAndFooterProps {
  onCreateFirstVideo: () => void;
  onOpenApiModal: () => void;
}

export const FinalCtaAndFooter: React.FC<FinalCtaAndFooterProps> = ({
  onCreateFirstVideo,
  onOpenApiModal,
}) => {
  return (
    <>
      {/* SECTION 8: Final Conversion CTA Banner */}
      <section className="relative py-20 sm:py-24 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="relative overflow-hidden rounded-3xl border border-[#00E5FF]/30 bg-gradient-to-br from-[#0B1224] via-[#090D1A] to-[#120B24] px-6 py-16 sm:px-14 sm:py-20 text-center shadow-[0_24px_90px_-20px_rgba(0,229,255,0.25)]">
            {/* Subtle Grid & Dual Radial Glows */}
            <div className="pointer-events-none absolute inset-0 bg-studio-grid opacity-70" />
            <div
              className="pointer-events-none absolute -top-24 -left-24 h-80 w-80 rounded-full opacity-35 blur-[100px]"
              style={{ background: "radial-gradient(circle, #00E5FF 0%, transparent 70%)" }}
            />
            <div
              className="pointer-events-none absolute -bottom-24 -right-24 h-80 w-80 rounded-full opacity-35 blur-[100px]"
              style={{ background: "radial-gradient(circle, #7C3AED 0%, transparent 70%)" }}
            />

            <div className="relative z-10 mx-auto max-w-3xl">
              <div className="inline-flex items-center gap-2 rounded-full border border-[#00E5FF]/30 bg-[#05070C]/60 backdrop-blur-md px-3.5 py-1 font-mono text-xs text-[#00E5FF] mb-5">
                <Sparkles className="h-3.5 w-3.5" />
                <span>50 FREE RENDER CREDITS INCLUDED</span>
              </div>

              <h2 className="font-heading text-3xl sm:text-5xl font-bold tracking-[-0.025em] leading-[1.1] text-[#F8FAFC]">
                Bring Your Creative Vision to Life Today
              </h2>

              <p className="mx-auto mt-4 max-w-xl text-base sm:text-lg text-[#CBD5E1]">
                Join over 45,000 creators rendering high-definition AI videos in seconds.
              </p>

              <div className="mt-9 flex flex-col sm:flex-row items-center justify-center gap-4">
                <button
                  type="button"
                  onClick={onCreateFirstVideo}
                  className="btn-glow-gradient inline-flex items-center justify-center gap-2.5 rounded-xl px-8 py-4 text-base font-semibold text-white cursor-pointer"
                >
                  <span>Create Your First AI Video Now</span>
                  <ArrowUpRight className="h-5 w-5" />
                </button>
              </div>

              <div className="mt-5 font-mono text-xs text-[#94A3B8]">
                Instant browser studio access • Zero GPU setup • Cancel anytime
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 9: Multi-Column Footer */}
      <footer className="border-t border-white/[0.08] bg-[#04060B] pt-16 pb-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-10 pb-14 border-b border-white/[0.07]">
            {/* Brand & Operational Status Column (Spans 2 cols on desktop) */}
            <div className="lg:col-span-2 space-y-5">
              <VidGenLogo />
              <p className="max-w-sm text-sm leading-relaxed text-[#94A3B8]">
                Real-time motion diffusion studio &amp; developer API for 4K cinematic text-to-video,
                artwork animation, and deterministic camera direction.
              </p>

              {/* Status Page Indicator */}
              <div className="inline-flex items-center gap-2.5 rounded-xl border border-[#10B981]/30 bg-[#10B981]/[0.07] px-3.5 py-2 font-mono text-xs text-[#E2E8F0]">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#10B981] opacity-75" />
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#10B981]" />
                </span>
                <span className="text-[#34D399] font-medium">● All GPU Clusters Operational</span>
              </div>
            </div>

            {/* Column 1: Product */}
            <div>
              <h4 className="font-heading text-sm font-semibold text-[#F8FAFC] mb-4">Product</h4>
              <ul className="space-y-2.5 text-sm text-[#94A3B8]">
                <li>
                  <a href="#hero-studio" className="hover:text-[#00E5FF] transition-colors">
                    Text-to-Video v3.0
                  </a>
                </li>
                <li>
                  <a href="#features" className="hover:text-[#00E5FF] transition-colors">
                    Image-to-Video
                  </a>
                </li>
                <li>
                  <a href="#features" className="hover:text-[#00E5FF] transition-colors">
                    Camera Director Rig
                  </a>
                </li>
                <li>
                  <a href="#features" className="hover:text-[#00E5FF] transition-colors">
                    Consistent Actor Lock
                  </a>
                </li>
                <li>
                  <a href="#pricing" className="hover:text-[#00E5FF] transition-colors">
                    Studio Pricing
                  </a>
                </li>
              </ul>
            </div>

            {/* Column 2: Models & Showcase */}
            <div>
              <h4 className="font-heading text-sm font-semibold text-[#F8FAFC] mb-4">Models</h4>
              <ul className="space-y-2.5 text-sm text-[#94A3B8]">
                <li>
                  <a href="#showcase" className="hover:text-[#00E5FF] transition-colors">
                    VidGen-Cinema v3.0
                  </a>
                </li>
                <li>
                  <a href="#showcase" className="hover:text-[#00E5FF] transition-colors">
                    VidGen-Commerce v3.0
                  </a>
                </li>
                <li>
                  <a href="#showcase" className="hover:text-[#00E5FF] transition-colors">
                    VidGen-Stylized 3D
                  </a>
                </li>
                <li>
                  <a href="#showcase" className="hover:text-[#00E5FF] transition-colors">
                    VidGen-FX Particle
                  </a>
                </li>
                <li>
                  <a href="#showcase" className="hover:text-[#00E5FF] transition-colors">
                    4K 60FPS Upscaler
                  </a>
                </li>
              </ul>
            </div>

            {/* Column 3: API Documentation & Developers */}
            <div>
              <h4 className="font-heading text-sm font-semibold text-[#F8FAFC] mb-4">
                API Documentation
              </h4>
              <ul className="space-y-2.5 text-sm text-[#94A3B8]">
                <li>
                  <button
                    type="button"
                    onClick={onOpenApiModal}
                    className="hover:text-[#00E5FF] transition-colors cursor-pointer"
                  >
                    REST API Quickstart
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={onOpenApiModal}
                    className="hover:text-[#00E5FF] transition-colors cursor-pointer"
                  >
                    Node.js &amp; Python SDKs
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={onOpenApiModal}
                    className="hover:text-[#00E5FF] transition-colors cursor-pointer"
                  >
                    Webhook Events
                  </button>
                </li>
                <li>
                  <a href="#api-docs" className="hover:text-[#00E5FF] transition-colors">
                    Custom LoRA Fine-Tuning
                  </a>
                </li>
                <li>
                  <a href="#faq" className="hover:text-[#00E5FF] transition-colors">
                    Rate Limits &amp; SLA
                  </a>
                </li>
              </ul>
            </div>

            {/* Column 4: Legal & Company */}
            <div>
              <h4 className="font-heading text-sm font-semibold text-[#F8FAFC] mb-4">
                Legal &amp; Trust
              </h4>
              <ul className="space-y-2.5 text-sm text-[#94A3B8]">
                <li>
                  <a href="#faq" className="hover:text-[#00E5FF] transition-colors">
                    Commercial License
                  </a>
                </li>
                <li>
                  <a href="#faq" className="hover:text-[#00E5FF] transition-colors">
                    Terms of Service
                  </a>
                </li>
                <li>
                  <a href="#faq" className="hover:text-[#00E5FF] transition-colors">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#faq" className="hover:text-[#00E5FF] transition-colors">
                    SOC2 Security
                  </a>
                </li>
                <li>
                  <a href="#faq" className="hover:text-[#00E5FF] transition-colors">
                    Content Safety &amp; C2PA
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Bar: Copyright & Social Links */}
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#64748B]">
            <p>© {new Date().getFullYear()} VidGen Technologies, Inc. All rights reserved.</p>

            {/* Social Links */}
            <div className="flex items-center gap-3">
              {/* X / Twitter */}
              <a
                href="#hero-studio"
                aria-label="VidGen on X"
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/[0.08] bg-white/[0.02] text-[#94A3B8] hover:border-[#00E5FF]/40 hover:text-[#00E5FF] transition-all"
              >
                <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
              </a>
              {/* GitHub */}
              <a
                href="#api-docs"
                aria-label="VidGen SDKs on GitHub"
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/[0.08] bg-white/[0.02] text-[#94A3B8] hover:border-[#00E5FF]/40 hover:text-[#00E5FF] transition-all"
              >
                <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"
                  />
                </svg>
              </a>
              {/* Discord */}
              <a
                href="#showcase"
                aria-label="VidGen Creator Discord"
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/[0.08] bg-white/[0.02] text-[#94A3B8] hover:border-[#00E5FF]/40 hover:text-[#00E5FF] transition-all"
              >
                <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028z" />
                </svg>
              </a>
              {/* YouTube */}
              <a
                href="#showcase"
                aria-label="VidGen 4K Showreels on YouTube"
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/[0.08] bg-white/[0.02] text-[#94A3B8] hover:border-[#00E5FF]/40 hover:text-[#00E5FF] transition-all"
              >
                <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
};
