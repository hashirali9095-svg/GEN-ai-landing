import React, { useState } from "react";
import { ChevronDown, HelpCircle } from "lucide-react";
import { FAQ_ITEMS } from "../data/studioData";

export const FaqAccordion: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section
      id="faq"
      className="relative border-t border-white/[0.07] bg-[#060912]/90 py-24 sm:py-28"
    >
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        {/* Heading */}
        <div className="text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-3.5 py-1 font-mono text-xs font-medium text-[#CBD5E1] mb-4">
            <HelpCircle className="h-3.5 w-3.5 text-[#00E5FF]" />
            <span>FREQUENTLY ASKED QUESTIONS</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl font-bold tracking-[-0.025em] text-[#F8FAFC]">
            Everything You Need to{" "}
            <span className="bg-gradient-to-r from-[#00E5FF] to-[#A855F7] bg-clip-text text-transparent">
              Ship Faster
            </span>
          </h2>
          <p className="mt-3 text-base text-[#94A3B8]">
            Technical answers on GPU latency, commercial IP ownership, API rate limits, and credit
            rollover.
          </p>
        </div>

        {/* Accordion List */}
        <div className="mt-12 space-y-3.5">
          {FAQ_ITEMS.map((item, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={item.question}
                className={`rounded-2xl border transition-all duration-200 ${
                  isOpen
                    ? "border-[#00E5FF]/40 bg-[#0B1020]/95 shadow-[0_0_32px_-8px_rgba(0,229,255,0.2)]"
                    : "border-white/[0.08] bg-[#090D19]/75 hover:border-white/20"
                }`}
              >
                <button
                  type="button"
                  aria-expanded={isOpen}
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left cursor-pointer"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3.5">
                    <span className="w-fit rounded-md border border-white/10 bg-white/[0.04] px-2 py-0.5 font-mono text-[10px] font-medium uppercase tracking-wider text-[#00E5FF]">
                      {item.tag}
                    </span>
                    <span className="font-heading text-base sm:text-lg font-semibold text-[#F8FAFC]">
                      {item.question}
                    </span>
                  </div>

                  <span
                    className={`inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border transition-all duration-200 ${
                      isOpen
                        ? "border-[#00E5FF]/40 bg-[#00E5FF]/15 text-[#00E5FF] rotate-180"
                        : "border-white/10 bg-white/[0.03] text-[#94A3B8]"
                    }`}
                  >
                    <ChevronDown className="h-4 w-4" />
                  </span>
                </button>

                {isOpen && (
                  <div className="px-6 pb-6 pt-0 text-sm sm:text-[15px] leading-relaxed text-[#94A3B8] border-t border-white/[0.06] mt-1 pt-4">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
