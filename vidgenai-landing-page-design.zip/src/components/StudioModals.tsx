import React, { useState } from "react";
import {
  X,
  Sparkles,
  CheckCircle2,
  Terminal,
  Copy,
  Check,
  Film,
  ArrowRight,
} from "lucide-react";
import { HERO_PRESETS } from "../data/studioData";
import { VidGenLogo } from "./Navbar";

interface ShowreelModalProps {
  open: boolean;
  onClose: () => void;
}

export const ShowreelModal: React.FC<ShowreelModalProps> = ({ open, onClose }) => {
  const [reelIdx, setReelIdx] = useState(0);

  if (!open) return null;
  const activeReel = HERO_PRESETS[reelIdx];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#030509]/85 backdrop-blur-xl p-4"
      role="dialog"
      aria-modal="true"
      aria-label="VidGen v3.0 Official 4K Showreel"
    >
      <div className="relative w-full max-w-5xl rounded-3xl border border-white/15 bg-[#080C17] overflow-hidden shadow-[0_30px_120px_rgba(0,229,255,0.28)]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 px-6 py-4">
          <div className="flex items-center gap-3">
            <Film className="h-5 w-5 text-[#00E5FF]" />
            <div>
              <h3 className="font-heading text-base font-bold text-white">
                VidGen v3.0 — Official 4K 60FPS Motion Showreel
              </h3>
              <p className="font-mono text-[11px] text-[#94A3B8]">
                100% Zero-Shot AI Output • Unedited H200 Real-Time Renders
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-white/10 bg-white/[0.04] p-2 text-[#94A3B8] hover:text-white cursor-pointer"
            aria-label="Close Showreel"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Video Player */}
        <div className="relative aspect-video w-full bg-black">
          <video
            key={activeReel.videoUrl}
            src={activeReel.videoUrl}
            poster={activeReel.posterUrl}
            autoPlay
            controls
            loop
            playsInline
            className="h-full w-full object-cover"
          />
        </div>

        {/* Reel Chapter Switcher */}
        <div className="border-t border-white/10 bg-[#0A0F1D] p-4 sm:px-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex flex-wrap gap-2">
            {HERO_PRESETS.map((preset, idx) => (
              <button
                key={preset.id}
                type="button"
                onClick={() => setReelIdx(idx)}
                className={`rounded-lg px-3 py-1.5 font-mono text-xs font-medium transition-all cursor-pointer ${
                  reelIdx === idx
                    ? "bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/45"
                    : "bg-white/[0.04] text-[#94A3B8] hover:text-white border border-white/10"
                }`}
              >
                0{idx + 1}. {preset.label}
              </button>
            ))}
          </div>
          <span className="font-mono text-xs text-[#34D399]">
            Rendered in {activeReel.renderTime} • {activeReel.resolution}
          </span>
        </div>
      </div>
    </div>
  );
};

interface AuthModalProps {
  open: boolean;
  mode: "signin" | "signup";
  selectedPlan?: string | null;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  open,
  mode,
  selectedPlan,
  onClose,
}) => {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  if (!open) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSubmitted(true);
  };

  const resetAndClose = () => {
    setSubmitted(false);
    setEmail("");
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#030509]/85 backdrop-blur-xl p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="relative w-full max-w-md rounded-3xl border border-white/15 bg-[#090D1A] p-7 sm:p-8 shadow-[0_30px_100px_rgba(124,58,237,0.3)]">
        <button
          type="button"
          onClick={resetAndClose}
          className="absolute top-5 right-5 rounded-lg border border-white/10 bg-white/[0.04] p-2 text-[#94A3B8] hover:text-white cursor-pointer"
          aria-label="Close Modal"
        >
          <X className="h-4 w-4" />
        </button>

        <VidGenLogo />

        {!submitted ? (
          <>
            <h3 className="mt-6 font-heading text-2xl font-bold text-white">
              {selectedPlan
                ? `Activate ${selectedPlan} Workspace`
                : mode === "signin"
                ? "Sign in to VidGen Studio"
                : "Claim Your 50 Free Render Credits"}
            </h3>
            <p className="mt-2 text-sm text-[#94A3B8]">
              {selectedPlan
                ? "Instant H200 priority queue provisioning with commercial IP ownership."
                : "Generate 4K 60FPS cinematic AI clips directly in your browser. No credit card required."}
            </p>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <div>
                <label className="block font-mono text-xs uppercase tracking-wider text-[#94A3B8] mb-1.5">
                  Work or Studio Email
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="director@studio.io"
                  className="w-full rounded-xl border border-white/15 bg-[#05070C] px-4 py-3 text-sm text-white placeholder-[#64748B] focus:border-[#00E5FF] focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="btn-glow-gradient w-full inline-flex items-center justify-center gap-2 rounded-xl py-3.5 text-sm font-semibold text-white cursor-pointer"
              >
                <Sparkles className="h-4 w-4" />
                <span>
                  {selectedPlan
                    ? `Continue to ${selectedPlan}`
                    : mode === "signin"
                    ? "Send Magic Studio Link"
                    : "Launch Free Studio (50 Credits)"}
                </span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </form>

            <p className="mt-4 text-center font-mono text-[11px] text-[#64748B]">
              SSO supported for Google, GitHub &amp; Okta Enterprise
            </p>
          </>
        ) : (
          <div className="mt-6 rounded-2xl border border-[#10B981]/35 bg-[#10B981]/10 p-6 text-center">
            <CheckCircle2 className="mx-auto h-10 w-10 text-[#34D399]" />
            <h4 className="mt-3 font-heading text-xl font-bold text-white">
              Studio Link Dispatched!
            </h4>
            <p className="mt-2 text-sm text-[#CBD5E1]">
              We sent an instant workspace launch link and{" "}
              <span className="text-[#00E5FF] font-semibold">50 free render credits</span> to{" "}
              <span className="font-mono text-white">{email}</span>.
            </p>
            <button
              type="button"
              onClick={resetAndClose}
              className="mt-5 rounded-xl border border-white/15 bg-white/10 hover:bg-white/15 px-5 py-2.5 text-xs font-semibold text-white cursor-pointer"
            >
              Return to Studio Preview
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

interface ApiDocsModalProps {
  open: boolean;
  onClose: () => void;
}

export const ApiDocsModal: React.FC<ApiDocsModalProps> = ({ open, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!open) return null;

  const curlSnippet = `curl -X POST https://api.vidgen.ai/v3/videos/generations \\
  -H "Authorization: Bearer vg_live_9948201a8f..." \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "vidgen-v3-ultra",
    "prompt": "Cinematic slow-motion cyberpunk skyline at twilight, 4k",
    "resolution": "3840x2160",
    "fps": 60,
    "camera": { "pan": 3.5, "orbit": 0, "zoom": 1.1 },
    "actor_lock_id": "actor_vg09",
    "webhook_url": "https://studio.example.com/webhooks/vidgen"
  }'`;

  const copyCurl = () => {
    navigator.clipboard.writeText(curlSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#030509]/85 backdrop-blur-xl p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="relative w-full max-w-2xl rounded-3xl border border-white/15 bg-[#080C17] p-6 sm:p-8 shadow-[0_30px_100px_rgba(0,229,255,0.22)]">
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <Terminal className="h-5 w-5 text-[#00E5FF]" />
            <h3 className="font-heading text-xl font-bold text-white">
              VidGen v3.0 REST API Quickstart
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-white/10 bg-white/[0.04] p-2 text-[#94A3B8] hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <p className="mt-4 text-sm text-[#94A3B8]">
          Dispatch deterministic 4K 60FPS renders asynchronously with sub-second H200 queue start
          and signed HMAC-SHA256 webhook events.
        </p>

        <div className="mt-4 rounded-2xl border border-white/10 bg-[#04060B] overflow-hidden">
          <div className="flex items-center justify-between border-b border-white/10 bg-[#0A0F1D] px-4 py-2.5 font-mono text-xs">
            <span className="text-[#00E5FF]">POST /v3/videos/generations</span>
            <button
              type="button"
              onClick={copyCurl}
              className="inline-flex items-center gap-1.5 text-[#CBD5E1] hover:text-white cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="h-3.5 w-3.5 text-[#10B981]" />
                  <span className="text-[#10B981]">Copied cURL</span>
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  <span>Copy cURL</span>
                </>
              )}
            </button>
          </div>
          <pre className="p-4 font-mono text-xs leading-relaxed text-[#E2E8F0] overflow-x-auto">
            <code>{curlSnippet}</code>
          </pre>
        </div>

        <div className="mt-5 grid grid-cols-3 gap-3 font-mono text-xs">
          <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
            <div className="text-[#64748B]">SDK PACKAGES</div>
            <div className="mt-1 text-white">npm i @vidgen/sdk</div>
          </div>
          <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
            <div className="text-[#64748B]">PYTHON PIP</div>
            <div className="mt-1 text-white">pip install vidgen</div>
          </div>
          <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
            <div className="text-[#64748B]">SLA UPTIME</div>
            <div className="mt-1 text-[#34D399]">99.98% Global</div>
          </div>
        </div>
      </div>
    </div>
  );
};
