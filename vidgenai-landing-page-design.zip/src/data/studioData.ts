export interface StudioPreset {
  id: string;
  label: string;
  prompt: string;
  videoUrl: string;
  posterUrl: string;
  seed: number;
  renderTime: string;
  motionStrength: number;
  fps: number;
  cameraControl: number; // -5 to +5 pan/orbit index
  cameraMode: string;
  model: string;
  resolution: string;
}

export interface ShowcaseCardItem {
  id: string;
  title: string;
  modelBadge: string;
  prompt: string;
  seed: string;
  cfgScale: string;
  motionScore: string;
  cameraTag: string;
  generationTime: string;
  resolution: string;
  videoUrl: string;
  posterUrl: string;
}

export interface ShowcaseCategory {
  id: string;
  label: string;
  modelName: string;
  latencyAvg: string;
  description: string;
  cards: [ShowcaseCardItem, ShowcaseCardItem];
}

export const HERO_PRESETS: StudioPreset[] = [
  {
    id: "cyberpunk-twilight",
    label: "Cyberpunk Twilight",
    prompt:
      "Cinematic slow-motion shot of a futuristic cyberpunk city at twilight, 8k resolution, camera pan right...",
    videoUrl:
      "https://videos.pexels.com/video-files/34719182/14717093_1920_1080_30fps.mp4",
    posterUrl:
      "https://images.pexels.com/videos/34719182/pexels-photo-34719182.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    seed: 88492014,
    renderTime: "0.78s",
    motionStrength: 7.8,
    fps: 60,
    cameraControl: 3.5,
    cameraMode: "Pan Right +4.2°",
    model: "VidGen v3.0 Ultra",
    resolution: "3840 × 2160 • 4K UHD",
  },
  {
    id: "hover-car-neon",
    label: "Neo-Tokyo Pursuit",
    prompt:
      "Low-angle tracking shot of an aerodynamic hover-coupe gliding through rain-slicked neon boulevards, volumetric fog, 60fps...",
    videoUrl:
      "https://videos.pexels.com/video-files/28615171/12433554_3840_2160_25fps.mp4",
    posterUrl:
      "https://images.pexels.com/videos/28615171/pexels-photo-28615171.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    seed: 51904432,
    renderTime: "0.84s",
    motionStrength: 8.6,
    fps: 60,
    cameraControl: 2.0,
    cameraMode: "Tracking Dolly +2.0x",
    model: "VidGen v3.0 Ultra",
    resolution: "3840 × 2160 • 4K UHD",
  },
  {
    id: "orbital-astronaut",
    label: "Orbital Visor Close-Up",
    prompt:
      "Anamorphic 35mm close-up of a deep-space explorer inside an illuminated helmet visor, subtle breathing mist, orbit camera...",
    videoUrl:
      "https://videos.pexels.com/video-files/7665028/7665028-hd_1920_1080_25fps.mp4",
    posterUrl:
      "https://images.pexels.com/videos/7665028/adult-armor-art-astronaut-7665028.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    seed: 19384710,
    renderTime: "0.72s",
    motionStrength: 5.4,
    fps: 24,
    cameraControl: -2.5,
    cameraMode: "Orbit Left -2.5°",
    model: "VidGen v3.0 Cinema",
    resolution: "3840 × 2160 • 4K RAW",
  },
  {
    id: "quantum-vortex",
    label: "Quantum Fluid VFX",
    prompt:
      "Bioluminescent cyan and electric violet particle vortex colliding in zero gravity, macro depth of field, 4k 60fps...",
    videoUrl:
      "https://videos.pexels.com/video-files/29585589/12734111_1920_1080_30fps.mp4",
    posterUrl:
      "https://images.pexels.com/videos/29585589/pexels-photo-29585589.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    seed: 77401928,
    renderTime: "0.69s",
    motionStrength: 9.2,
    fps: 60,
    cameraControl: 4.0,
    cameraMode: "Zoom Push +1.4x",
    model: "VidGen v3.0 FX",
    resolution: "3840 × 2160 • 4K UHD",
  },
];

export const SHOWCASE_CATEGORIES: ShowcaseCategory[] = [
  {
    id: "cinematic",
    label: "Cinematic Film",
    modelName: "VidGen-Cinema v3.0",
    latencyAvg: "1.9s avg 4K",
    description:
      "Anamorphic lens physics, realistic skin subsurface scattering, atmospheric rain, and director-grade 6-axis camera rigs.",
    cards: [
      {
        id: "cinema-1",
        title: "Flooded Megacity Noir",
        modelBadge: "VidGen-Cinema v3.0",
        prompt:
          "Wide anamorphic aerial crane shot descending into a flooded cyberpunk megacity at midnight, neon billboards reflecting on rippling dark water, volumetric rain, ARRI Alexa 65 color science, 4K 60fps.",
        seed: "40928174",
        cfgScale: "7.5",
        motionScore: "8.2 / 10",
        cameraTag: "Crane Down + Pan",
        generationTime: "2.1s",
        resolution: "4K • 60FPS",
        videoUrl:
          "https://videos.pexels.com/video-files/39371134/16760232_3840_2160_25fps.mp4",
        posterUrl:
          "https://images.pexels.com/videos/39371134/pexels-photo-39371134.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
      },
      {
        id: "cinema-2",
        title: "Interstellar Airlock Telemetry",
        modelBadge: "VidGen-Cinema v3.0",
        prompt:
          "Handheld 50mm portrait inside a dimly lit orbital spacecraft cabin, female astronaut inspecting tungsten-lit instrumentation panels, shallow depth of field f/1.4, natural micro-expressions.",
        seed: "91827364",
        cfgScale: "7.0",
        motionScore: "6.4 / 10",
        cameraTag: "Subtle Handheld Orbit",
        generationTime: "1.8s",
        resolution: "4K • 24FPS",
        videoUrl:
          "https://videos.pexels.com/video-files/7665027/7665027-hd_1920_1080_25fps.mp4",
        posterUrl:
          "https://images.pexels.com/videos/7665027/pexels-photo-7665027.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
      },
    ],
  },
  {
    id: "ecommerce",
    label: "E-Commerce Ads",
    modelName: "VidGen-Commerce v3.0",
    latencyAvg: "1.5s avg 4K",
    description:
      "Turn single product studio PNGs into high-converting macro commercials with caustic glass reflections and studio rim-lighting.",
    cards: [
      {
        id: "ecom-1",
        title: "Chronograph Tourbillon Macro",
        modelBadge: "VidGen-Commerce v3.0",
        prompt:
          "Ultra-macro slow-motion commercial shot of a luxury skeleton mechanical watch, exposed silver tourbillon gears ticking with razor-sharp specular rim lighting, smooth motorized turntable orbit.",
        seed: "33019482",
        cfgScale: "8.0",
        motionScore: "5.8 / 10",
        cameraTag: "Macro Orbit 15°",
        generationTime: "1.6s",
        resolution: "4K • 60FPS",
        videoUrl:
          "https://videos.pexels.com/video-files/6867665/6867665-uhd_3840_2160_25fps.mp4",
        posterUrl:
          "https://images.pexels.com/videos/6867665/clock-clock-shield-luxurious-silver-6867665.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
      },
      {
        id: "ecom-2",
        title: "Botanical Elixir Dew Drops",
        modelBadge: "VidGen-Commerce v3.0",
        prompt:
          "High-speed 120fps studio tabletop shot of crystal water droplets rolling down a minimalist glass perfume flacon on dark obsidian stone, soft cyan-amber backlight caustics, luxury skincare ad.",
        seed: "64729105",
        cfgScale: "7.8",
        motionScore: "7.1 / 10",
        cameraTag: "Slow Push-In",
        generationTime: "1.4s",
        resolution: "4K • 60FPS",
        videoUrl:
          "https://videos.pexels.com/video-files/7815759/7815759-hd_1920_1080_25fps.mp4",
        posterUrl:
          "https://images.pexels.com/videos/7815759/background-beach-black-cold-7815759.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
      },
    ],
  },
  {
    id: "anime-3d",
    label: "Anime & 3D",
    modelName: "VidGen-Stylized 3D",
    latencyAvg: "1.3s avg 4K",
    description:
      "Octane-caliber 3D motion graphics, stylized cybernetic character animation, cel-shaded lighting, and seamless loop geometry.",
    cards: [
      {
        id: "anime-1",
        title: "Cybernetic Android Groove",
        modelBadge: "VidGen-Stylized 3D",
        prompt:
          "Stylized Unreal Engine 5 3D animation of chrome humanoid androids performing fluid motion-captured choreography in a neon-drenched Shibuya plaza, raytraced reflections, vibrant cyan-magenta rim light.",
        seed: "55820194",
        cfgScale: "8.5",
        motionScore: "9.0 / 10",
        cameraTag: "Dynamic Low-Angle",
        generationTime: "1.9s",
        resolution: "4K • 60FPS",
        videoUrl:
          "https://videos.pexels.com/video-files/29724117/12779426_3840_2160_24fps.mp4",
        posterUrl:
          "https://images.pexels.com/videos/29724117/dancing-robot-29724117.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
      },
      {
        id: "anime-2",
        title: "Hyper-Drive Octagon Portal",
        modelBadge: "VidGen-Stylized 3D",
        prompt:
          "Seamless 3D geometric sci-fi tunnel render with glowing electric cyan and ultraviolet octagon rings, high-velocity forward camera flythrough, Octane Render subsurface bloom, 60fps loop.",
        seed: "11049382",
        cfgScale: "7.2",
        motionScore: "9.4 / 10",
        cameraTag: "Z-Axis Flythrough",
        generationTime: "1.2s",
        resolution: "4K • 60FPS",
        videoUrl:
          "https://videos.pexels.com/video-files/2759486/2759486-uhd_3840_2160_30fps.mp4",
        posterUrl:
          "https://images.pexels.com/videos/2759486/free-video-2759486.jpg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
      },
    ],
  },
  {
    id: "vfx",
    label: "VFX & Particles",
    modelName: "VidGen-FX Particle",
    latencyAvg: "0.9s avg 4K",
    description:
      "GPU-accelerated fluid dynamics, Houdini-grade particle advection, volumetric shockwaves, and alpha-ready compositing plates.",
    cards: [
      {
        id: "vfx-1",
        title: "Plasma Singularity Advection",
        modelBadge: "VidGen-FX Particle",
        prompt:
          "Millions of luminous bioluminescent cyan and violet particles swirling into a gravitational singularity against pitch-black studio space, physically accurate turbulence curl noise, 4K VFX plate.",
        seed: "77291038",
        cfgScale: "8.2",
        motionScore: "9.6 / 10",
        cameraTag: "Vortex Zoom In",
        generationTime: "0.9s",
        resolution: "4K • 60FPS",
        videoUrl:
          "https://videos.pexels.com/video-files/34128974/14471955_3840_2160_30fps.mp4",
        posterUrl:
          "https://images.pexels.com/videos/34128974/abstract-animation-appear-background-34128974.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
      },
      {
        id: "vfx-2",
        title: "Iridescent Liquid Silk Simulation",
        modelBadge: "VidGen-FX Particle",
        prompt:
          "Real-time neon fluid dynamics simulation, electric cyan and ultraviolet plasma ribbons undulating in zero gravity, silky optical flow motion blur, clean black compositing background.",
        seed: "28491044",
        cfgScale: "7.6",
        motionScore: "8.8 / 10",
        cameraTag: "Locked Plate 60FPS",
        generationTime: "1.1s",
        resolution: "4K • 60FPS",
        videoUrl:
          "https://videos.pexels.com/video-files/29539050/12715465_1920_1080_30fps.mp4",
        posterUrl:
          "https://images.pexels.com/videos/29539050/pexels-photo-29539050.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
      },
    ],
  },
];

export const ACTOR_LOCK_SCENES = [
  {
    id: "scene-01",
    sceneCode: "SCENE 01",
    location: "Neon Street • Wide",
    matchScore: "99.7%",
    imageUrl:
      "https://images.pexels.com/photos/8107826/pexels-photo-8107826.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    id: "scene-02",
    sceneCode: "SCENE 02",
    location: "Close-Up • 85mm",
    matchScore: "99.5%",
    imageUrl:
      "https://images.pexels.com/photos/8107950/pexels-photo-8107950.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    id: "scene-03",
    sceneCode: "SCENE 03",
    location: "Cyber Lounge • Interior",
    matchScore: "99.4%",
    imageUrl:
      "https://images.pexels.com/photos/8107819/pexels-photo-8107819.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
];

export interface PricingTier {
  id: string;
  name: string;
  tagline: string;
  monthlyPrice: number;
  annualPrice: number;
  annualNote: string;
  popular?: boolean;
  ctaLabel: string;
  creditsBadge: string;
  features: string[];
}

export const PRICING_TIERS: PricingTier[] = [
  {
    id: "creator",
    name: "Creator",
    tagline: "For solo filmmakers, designers, and rapid concept prototyping.",
    monthlyPrice: 19,
    annualPrice: 15,
    annualNote: "Billed annually ($180/yr)",
    ctaLabel: "Start Creator Plan",
    creditsBadge: "500 render credits / mo",
    features: [
      "500 render credits/mo (~100 HD clips)",
      "1080p Full HD resolution exports",
      "Standard GPU render queue",
      "Text-to-Video & Image-to-Video access",
      "Watermark-free MP4 & WebM downloads",
      "Personal license included",
    ],
  },
  {
    id: "pro-studio",
    name: "Pro Studio",
    tagline: "Built for production studios, ad agencies, and commercial teams.",
    monthlyPrice: 49,
    annualPrice: 39,
    annualNote: "Billed annually ($468/yr)",
    popular: true,
    ctaLabel: "Upgrade to Pro Studio",
    creditsBadge: "2,500 render credits / mo",
    features: [
      "2,500 render credits/mo + 60-day rollover",
      "Native 4K UHD resolution & 60FPS interpolation",
      "Priority H200 GPU render queue (0.8s start)",
      "Full Camera Control Suite (Zoom, Pan, Orbit, Crane)",
      "Consistent Actor Lock across unlimited scenes",
      "Full Commercial License & copyright ownership",
    ],
  },
  {
    id: "enterprise",
    name: "Enterprise",
    tagline: "Dedicated compute, custom fine-tuning, and high-throughput APIs.",
    monthlyPrice: 149,
    annualPrice: 119,
    annualNote: "Billed annually ($1,428/yr) • $149/mo monthly",
    ctaLabel: "Deploy Enterprise Studio",
    creditsBadge: "Unlimited render credits",
    features: [
      "Unlimited render credits (zero throttling)",
      "Custom model fine-tuning (LoRA & brand style lock)",
      "Dedicated isolated GPU cluster",
      "Full REST API, Webhooks & Python/Node SDKs",
      "SOC2 Type II privacy & zero-retention mode",
      "99.9% uptime SLA & dedicated solutions engineer",
    ],
  },
];

export interface FAQItem {
  question: string;
  answer: string;
  tag: string;
}

export const FAQ_ITEMS: FAQItem[] = [
  {
    tag: "Performance",
    question: "How fast are VidGen v3.0 rendering times in real-world production?",
    answer:
      "Powered by our Real-Time Motion Diffusion architecture running on distributed NVIDIA H200 clusters, interactive latent previews stream in ~0.8 seconds. Full studio-grade 4K 60FPS clips complete in 1.4 to 2.4 seconds on Priority and Dedicated GPU queues with zero cold-start spin-up.",
  },
  {
    tag: "Licensing & IP",
    question: "Who owns the commercial copyright to videos generated on VidGen.ai?",
    answer:
      "You retain 100% commercial copyright ownership and exclusive distribution rights for every video rendered under Pro Studio, Enterprise, and even our 50 free trial credits. Your outputs are royalty-free forever across broadcast TV, paid social ads, feature films, and client deliverables.",
  },
  {
    tag: "Developers & API",
    question: "What are the REST API rate limits and webhook capabilities?",
    answer:
      "Our v3 REST API and official TypeScript/Python SDKs support asynchronous webhook callbacks with HMAC-SHA256 verification. Pro Studio keys include 30 concurrent generations/minute, while Enterprise clusters scale to 120+ concurrent 4K renders/minute with sub-second queue dispatch and 99.9% SLA.",
  },
  {
    tag: "Billing & Credits",
    question: "How do render credits work, and do unused credits roll over?",
    answer:
      "A standard 5-second 1080p clip uses 5 credits, while a native 4K 60FPS render with Camera Director Controls uses 10 credits. On Pro Studio plans, unused monthly credits automatically roll over for up to 60 days. On-demand credit top-up packs never expire, and Enterprise plans include unlimited rendering.",
  },
  {
    tag: "Consistency",
    question: "How does Consistent Actor Lock maintain character identity across scenes?",
    answer:
      "Upload 1 to 4 reference portraits or lock any generated frame to mint a persistent Actor ID. VidGen v3.0 conditions facial geometry, wardrobe textures, and lighting response across distinct camera angles, focal lengths, and environments with over 99.4% biometric feature consistency.",
  },
  {
    tag: "Security",
    question: "Are uploaded Figma frames, storyboards, or client assets used to train models?",
    answer:
      "Never on paid studio workspaces. All uploaded source images, proprietary product renders, and generated videos on Pro Studio and Enterprise tiers are encrypted at rest (AES-256) and strictly excluded from foundation model training.",
  },
];
