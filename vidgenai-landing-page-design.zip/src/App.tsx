import { useState, useRef } from "react";
import { Navbar } from "./components/Navbar";
import { HeroStudio } from "./components/HeroStudio";
import { SocialProofWall } from "./components/SocialProofWall";
import { FeatureBentoGrid } from "./components/FeatureBentoGrid";
import { ModelShowcase } from "./components/ModelShowcase";
import { PricingSection } from "./components/PricingSection";
import { FaqAccordion } from "./components/FaqAccordion";
import { FinalCtaAndFooter } from "./components/FinalCtaAndFooter";
import { ShowreelModal, AuthModal, ApiDocsModal } from "./components/StudioModals";
import { StudioPreset } from "./data/studioData";

export function App() {
  const [externalStudioPreset, setExternalStudioPreset] = useState<StudioPreset | null>(null);
  const [showreelOpen, setShowreelOpen] = useState<boolean>(false);
  const [apiModalOpen, setApiModalOpen] = useState<boolean>(false);
  const [authModal, setAuthModal] = useState<{
    open: boolean;
    mode: "signin" | "signup";
    plan?: string | null;
  }>({
    open: false,
    mode: "signup",
    plan: null,
  });

  const promptInputRef = useRef<HTMLInputElement | null>(null);

  const handleFocusStudio = () => {
    const studioEl = document.getElementById("hero-studio");
    if (studioEl) {
      studioEl.scrollIntoView({ behavior: "smooth", block: "center" });
      setTimeout(() => {
        promptInputRef.current?.focus();
      }, 450);
    }
  };

  const handleLoadShowcaseIntoStudio = (preset: StudioPreset) => {
    setExternalStudioPreset({ ...preset });
    const studioEl = document.getElementById("hero-studio");
    if (studioEl) {
      studioEl.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  const handleSelectPlan = (planName: string, billing: "monthly" | "annual") => {
    setAuthModal({
      open: true,
      mode: "signup",
      plan: `${planName} (${billing === "annual" ? "Annual -20%" : "Monthly"})`,
    });
  };

  return (
    <div className="min-h-screen bg-[#05070C] text-[#F8FAFC] selection:bg-[#00E5FF]/25 selection:text-[#00E5FF]">
      {/* 1. Sticky Navigation Header */}
      <Navbar
        onOpenAuth={(mode) => setAuthModal({ open: true, mode, plan: null })}
        onFocusStudio={handleFocusStudio}
        onOpenApiModal={() => setApiModalOpen(true)}
      />

      <main>
        {/* 2. Hero Section + Interactive 16:9 Video Studio Preview */}
        <HeroStudio
          externalPreset={externalStudioPreset}
          promptInputRef={promptInputRef}
          onOpenShowreel={() => setShowreelOpen(true)}
          onStartFree={() => setAuthModal({ open: true, mode: "signup", plan: null })}
        />

        {/* 3. Social Proof & Studio Wall */}
        <SocialProofWall />

        {/* 4. Feature Bento Grid (3x2 Layout) */}
        <FeatureBentoGrid onOpenApiModal={() => setApiModalOpen(true)} />

        {/* 5. Interactive Prompt & Model Showcase (Tabbed Interface) */}
        <ModelShowcase onLoadIntoStudio={handleLoadShowcaseIntoStudio} />

        {/* 6. Transparent Pricing (Monthly / Annual Billing Toggle with 20% Discount) */}
        <PricingSection onSelectPlan={handleSelectPlan} />

        {/* 7. FAQ Accordion System */}
        <FaqAccordion />

        {/* 8. Final Conversion CTA Banner & 9. Multi-Column Footer */}
        <FinalCtaAndFooter
          onCreateFirstVideo={() => setAuthModal({ open: true, mode: "signup", plan: null })}
          onOpenApiModal={() => setApiModalOpen(true)}
        />
      </main>

      {/* Interactive Modals */}
      <ShowreelModal open={showreelOpen} onClose={() => setShowreelOpen(false)} />

      <AuthModal
        open={authModal.open}
        mode={authModal.mode}
        selectedPlan={authModal.plan}
        onClose={() => setAuthModal((prev) => ({ ...prev, open: false }))}
      />

      <ApiDocsModal open={apiModalOpen} onClose={() => setApiModalOpen(false)} />
    </div>
  );
}

export default App;
